from pathlib import Path
import sys,pcbnew as p,json,hashlib
BP=Path(sys.argv[1]);OUT=Path(sys.argv[2]);sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();S=sha(BP);b=p.LoadBoard(str(BP));items=list(b.GetTracks())+[q for f in b.GetFootprints()for q in f.Pads()];uid=lambda q:q.m_Uuid.AsString();vec=lambda a:p.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6));box=p.BOX2I(vec([10,12]),vec([14,13]));layers=[p.F_Cu,p.In1_Cu,p.In2_Cu,p.B_Cu]
def poly(shape,out=False):
 q=p.SHAPE_POLY_SET();shape.TransformToPolygon(q,1,p.ERROR_OUTSIDE if out else p.ERROR_INSIDE);q.Simplify();return q
def dump(q):
 def pts(r):return [[r.CPoint(i).x,r.CPoint(i).y]for i in range(r.PointCount())]
 return [{'outer':pts(q.COutline(i)),'holes':[pts(q.CHole(i,h))for h in range(q.HoleCount(i))]}for i in range(q.OutlineCount())]
H=[];holes=[]
for q in items:
 if isinstance(q,(p.PAD,p.PCB_VIA))and q.HasHole():
  assert not isinstance(q,p.PCB_VIA)or q.GetViaType()==p.VIATYPE_THROUGH
  h=poly(q.GetEffectiveHoleShape(),True);H.append((h.BBox(),h));holes.append({'uuid':uid(q),'type':'via'if isinstance(q,p.PCB_VIA)else'pad','polygon':dump(h)})
def metal(q,l):
 c=poly(q.GetEffectiveShape(l));bb=c.BBox()
 for hb,h in H:
  if bb.Intersects(hb):c.BooleanSubtract(h)
 return c
nodes=[];C={}
for q in items:
 if not box.Intersects(q.GetBoundingBox())or not q.IsOnLayer(p.B_Cu):continue
 c=metal(q,p.B_Cu);C[uid(q)]=c;r={'uuid':uid(q),'net':q.GetNetname(),'kind':type(q).__name__,'metal_B':dump(c)}
 if isinstance(q,p.PAD):r.update(reference=q.GetParentFootprint().GetReference(),number=q.GetNumber(),at=[q.GetPosition().x/1e6,q.GetPosition().y/1e6],size=[q.GetSize().x/1e6,q.GetSize().y/1e6],layers=[b.GetLayerName(l)for l in q.GetLayerSet().Seq()])
 elif isinstance(q,p.PCB_VIA):r.update(at=[q.GetPosition().x/1e6,q.GetPosition().y/1e6],diameter=q.GetWidth(p.B_Cu)/1e6,drill=q.GetDrillValue()/1e6)
 else:r.update(start=[q.GetStart().x/1e6,q.GetStart().y/1e6],end=[q.GetEnd().x/1e6,q.GetEnd().y/1e6],width=q.GetWidth()/1e6,length=q.GetLength()/1e6)
 nodes.append(r)
planes={}
for l in[p.In1_Cu,p.In2_Cu]:
 z=p.SHAPE_POLY_SET()
 for zz in b.Zones():
  if zz.GetNetname()=='GND'and zz.IsOnLayer(l):z.BooleanAdd(zz.GetFilledPolysList(l))
 # export local clip only, using exact native integer rectangle.
 clip=p.SHAPE_POLY_SET();clip.NewOutline()
 for x,y in[(10,12),(24,12),(24,25),(10,25)]:clip.Append(round(x*1e6),round(y*1e6))
 z.BooleanIntersection(clip)
 for hb,h in H:
  if z.BBox().Intersects(hb):z.BooleanSubtract(h)
 planes[b.GetLayerName(l)]=dump(z)
edges=[]
for i,a in enumerate(nodes):
 for c in nodes[i+1:]:
  if a['net']!=c['net']or not C[a['uuid']].BBox().Intersects(C[c['uuid']].BBox()):continue
  z=p.SHAPE_POLY_SET();z.BooleanIntersection(C[a['uuid']],C[c['uuid']]);ar=z.Area()/1e12
  if ar>0:edges.append({'a':a['uuid'],'b':c['uuid'],'net':a['net'],'area_mm2':ar})
R={'source':str(BP),'sha256':S,'nodes':nodes,'edges':edges,'inner_planes':planes,'all_physical_holes':holes,'method':'Canonical GetTracks/Pads; all physical through holes cut every layer before contact;1nm inside copper/outside holes','source_unchanged':sha(BP)==S};OUT.write_text(json.dumps(R,separators=(',',':')));print('EXPORTED',S,len(nodes),len(edges),len(holes),flush=True)

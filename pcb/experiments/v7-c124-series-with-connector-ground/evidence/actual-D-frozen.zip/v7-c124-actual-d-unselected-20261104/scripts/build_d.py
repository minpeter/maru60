from pathlib import Path
import re,json,hashlib,shutil
from sexpr_spans import *
R=Path('/tmp/v7-c124-d-actual');C=Path('/tmp/v7-c124-c-actual');CP=C/'filled/pcb';IP=Path('/tmp/v7-r121-rn73r-local-study/CONSTRUCTION_INPUT_CONTRACT.json');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert sha(IP)=='15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd';ct=json.loads(IP.read_text());SRC=Path(ct['construction_base']['project_path']);assert sha(SRC/'maru60.kicad_pcb')==ct['construction_base']['board_sha256'];assert sha(CP/'maru60.kicad_pcb')==ct['analysis_C_board_sha256'];assert sha(C/'BUILD_CONTRACT.json')==ct['base_C_circuit_contract_sha256'];assert not(R/'source').exists()and not(R/'prefill').exists()
shutil.copytree(SRC,R/'source/pcb');shutil.copytree(SRC,R/'prefill/pcb');T=R/'prefill/pcb';shutil.copy2(IP,R/'CONSTRUCTION_INPUT_CONTRACT.json');bc=json.loads((C/'BUILD_CONTRACT.json').read_text());orig=(SRC/'maru60.kicad_pcb').read_text();cs=(CP/'maru60.kicad_pcb').read_text();uid=lambda t:re.search(r'\(uuid "([^"]+)"\)',t).group(1)
def objidx(s):return{uid(t):t for _,_,t in children(s)if re.search(r'\(uuid "([^"]+)"\)',t)}
si=objidx(orig);ci=objidx(cs);remote=set(ct['construction_base']['retain_remote_retirements']);assert remote.isdisjoint(si)
ret=set(bc['retired_track_uuids']);assert len(ret)==31 and ret.issubset(si)
Ctracks={q['uuid']:q for q in bc['added_tracks']};assert set(ct['retire_relative_to_C']).issubset(Ctracks)
tracks=[q for q in bc['added_tracks']if q['uuid']not in ct['retire_relative_to_C']]+[dict(q,width=q['width_mm'])for q in ct['added_tracks']];assert len(tracks)==31;assert all(q['uuid']not in si for q in tracks)
fp={r:ci[ct['parts'][r]['uuid']]for r in ct['parts']};fmt=lambda x:format(x,'.9f').rstrip('0').rstrip('.');netcodes={m.group(2):int(m.group(1))for m in re.finditer(r'\(net (\d+) "([^"]+)"\)',orig)};assert 'USB_DVDT_CAP'not in netcodes;netcodes['USB_DVDT_CAP']=max(netcodes.values())+1
# Change only declared dimensions, pose/reference compensation and R121 identity fields.
oldname=bc['parts']['R121']['name'];newname=ct['parts']['R121']['name']
def mutate(t,ref,board):
 v=ct['parts'][ref]
 if ref=='R121':t=t.replace(oldname,newname)
 ed=[]
 for a,z,q in children(t):
  h=head(q)
  if h=='at'and board:ed.append((a,z,'(at '+' '.join(fmt(x)for x in v['at'])+')'))
  elif h=='property':
   name=re.match(r'\(property "([^"]+)"',q).group(1)
   if name=='Reference'and board:q=replace_child(q,'at',f'(at {fmt(v["refat"][0]-v["at"][0])} {fmt(v["refat"][1]-v["at"][1])} 0)')
   if ref=='R121'and name in['Manufacturer','MPN','Datasheet']:
    val={'Manufacturer':v['maker'],'MPN':v['mpn'],'Datasheet':v['datasheet']}[name];q=re.sub(r'^(\(property "[^"]+" )"[^"]*"',lambda m:m.group(1)+'"'+val+'"',q)
   ed.append((a,z,q))
  elif h=='fp_rect':
   layer=re.search(r'\(layer "([^"]+)"\)',q).group(1)
   if layer=='B.CrtYd'or(ref=='R121'and layer=='B.Fab'):
    wh=v['court']if layer=='B.CrtYd'else v['body'];q=replace_child(q,'start',f'(start {fmt(-wh[0]/2)} {fmt(-wh[1]/2)})');q=replace_child(q,'end',f'(end {fmt(wh[0]/2)} {fmt(wh[1]/2)})');ed.append((a,z,q))
  elif h=='pad'and ref=='R121':
   num=re.match(r'\(pad "([^"]+)"',q).group(1);row=next(x for x in v['pads']if x[0]==num);q=replace_child(q,'at',f'(at {fmt(row[1])} {fmt(row[2])})');q=replace_child(q,'size',f'(size {fmt(row[3])} {fmt(row[4])})');ed.append((a,z,q))
 for a,z,q in sorted(ed,reverse=True):t=t[:a]+q+t[z:]
 return t
for ref in['C124','R121']:fp[ref]=mutate(fp[ref],ref,True)
ed=[]
for a,z,t in children(orig):
 if head(t)in['segment','arc','via']and uid(t)in ret:assert head(t)=='segment';ed.append((a,z,''))
 if head(t)=='footprint':
  ref=re.search(r'\(property "Reference" "([^"]+)"',t).group(1)
  if ref in['C124','R121']:ed.append((a,z,fp[ref]))
s=orig
for a,z,t in sorted(ed,reverse=True):s=s[:a]+t+s[z:]
firstfp=next(a for a,z,t in children(s)if head(t)=='footprint');s=s[:firstfp]+f'(net {netcodes["USB_DVDT_CAP"]} "USB_DVDT_CAP")\n\t'+s[firstfp:];adds=[fp['R125']]
for q in tracks:
 if q['uuid']in ci:adds.append(ci[q['uuid']])
 else:adds.append(f'(segment (start {fmt(q["start_nm"][0]/1e6)} {fmt(q["start_nm"][1]/1e6)}) (end {fmt(q["end_nm"][0]/1e6)} {fmt(q["end_nm"][1]/1e6)}) (width {fmt(q["width_nm"]/1e6)}) (layer "B.Cu") (net {netcodes[q["net"]]}) (uuid "{q["uuid"]}"))')
s=s.rstrip();s=s[:-1]+'\n'+'\n'.join(adds)+'\n)\n';(T/'maru60.kicad_pcb').write_text(s);di=objidx(s);assert remote.isdisjoint(di)
# Carry only previously reviewed C companion delta, never the whole C board/fill.
for n in['protection-input-protection.kicad_sch','Study.kicad_sym','fp-lib-table']:shutil.copy2(CP/n,T/n)
shutil.copytree(CP/'C124_Short_Study.pretty',T/'C124_Short_Study.pretty')
sch=T/'protection-input-protection.kicad_sch';ss=sch.read_text();ed=[]
for a,z,t in children(ss):
 if head(t)=='symbol'and'(lib_id'in t and re.search(r'\(property "Reference" "R121"',t):
  for k,v in ct['companion_decisions']['R121_required_fields'].items():t=re.sub(r'(\(property "'+re.escape(k)+r'" )"[^"]*"',lambda m:m.group(1)+'"'+v+'"',t)
  ed.append((a,z,t))
assert len(ed)==1
for a,z,t in ed:ss=ss[:a]+t+ss[z:]
sch.write_text(ss)
lib=T/'C124_Short_Study.pretty';oldmod=lib/(oldname+'.kicad_mod');(lib/(newname+'.kicad_mod')).write_text(mutate(oldmod.read_text(),'R121',False));cmod=lib/(ct['parts']['C124']['name']+'.kicad_mod');cmod.write_text(mutate(cmod.read_text(),'C124',False))
# Old TNPW module remains unbound and byte-exact, as explicitly permitted.
assert oldmod.read_bytes()==(CP/'C124_Short_Study.pretty'/oldmod.name).read_bytes()
parts=ct['parts'];(R/'BOM_PROPOSAL.json').write_text(json.dumps({'status':'UNSELECTED proposed D components; no procurement or qualification','parts':parts,'qualification':ct['qualification']},indent=2)+'\n');out={'status':'UNSELECTED actual D, native validation pending','source_sha256':sha(SRC/'maru60.kicad_pcb'),'C_analysis_sha256':sha(CP/'maru60.kicad_pcb'),'construction_contract_sha256':sha(IP),'candidate_prefill_sha256':sha(T/'maru60.kicad_pcb'),'retired_track_uuids':sorted(ret),'C_relative_retired':ct['retire_relative_to_C'],'changed_old_footprint_uuids':[parts[r]['uuid']for r in['C124','R121']],'added_tracks':tracks,'parts':parts,'new_drills':0,'preserved_remote_retirements':sorted(remote),'qualification':ct['qualification']};(R/'BUILD_CONTRACT.json').write_text(json.dumps(out,indent=2)+'\n')
for name,tree in[('source',R/'source/pcb'),('prefill',T)]:
 files=[{'path':str(p.relative_to(tree)),'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(tree.rglob('*'))if p.is_file()];(R/f'{name.upper()}_TREE_MANIFEST.json').write_text(json.dumps({'count':len(files),'files':files},indent=2)+'\n')
shutil.copytree(T,R/'filled/pcb');assert sha(SRC/'maru60.kicad_pcb')==ct['construction_base']['board_sha256'];assert sha(CP/'maru60.kicad_pcb')==ct['analysis_C_board_sha256'];print(json.dumps({'prefill_sha256':sha(T/'maru60.kicad_pcb'),'source_retired':len(ret),'source_added':len(tracks),'C_relative_retired':2,'C_relative_added':10,'new_drills':0,'status':'Actual D prefill saved; UNSELECTED and not validated'},indent=2))

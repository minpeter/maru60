import os
os.environ['MPLCONFIGDIR']='/tmp/v7-c124-d-actual/plot-cache'
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch,Patch
from pathlib import Path as P
import json,hashlib
R=P('/tmp/v7-c124-d-actual');pal={'GND':'#6e9b75','USB_DVDT':'#d99100','USB_DVDT_CAP':'#00a6ba','USB_OVLO':'#9b51ab','USB_UVLO':'#3d68c8','USB_ILM':'#d44d3a','VBUS_PROTECTED_RAW':'#db6964','VBUS_FUSED':'#c95c52'}
s=json.loads((R/'qa/source-local-native-view.json').read_text());d=json.loads((R/'qa/local-native-view.json').read_text())
fig,axs=plt.subplots(1,2,figsize=(17,9));fig.patch.set_facecolor('#f5f7fa')
for ax,doc,title in [(axs[0],s,'Selected source c77020ca'),(axs[1],d,'UNSELECTED D f987edb4')]:
 ax.set_facecolor('white');ax.set_title(title,fontsize=15,fontweight='bold')
 for row in doc['layers']['B.Cu']:
  typ=row['type'];col=pal.get(row.get('net'),'#8c929b') if typ=='copper' else '#242a33' if typ=='silk' else '#65788b' if typ=='fab' else '#aab4c1'
  for z in row['poly']:
   vs=[];cs=[]
   for ring in [z['o']]+z['h']:
    if len(ring)<3:continue
    vs+=ring+[ring[0]];cs+=[Path.MOVETO]+[Path.LINETO]*(len(ring)-1)+[Path.CLOSEPOLY]
   if vs:ax.add_patch(PathPatch(Path(vs,cs),facecolor=col,edgecolor='none',alpha=.85 if typ=='copper' else .9 if typ=='silk' else .7,zorder=3 if typ=='silk' else 2 if typ=='copper' else 1))
 ax.set_xlim(7.0,22.5);ax.set_ylim(22.5,15.7);ax.set_aspect('equal');ax.set_xlabel('Board X (mm)');ax.set_ylabel('Board Y (mm)');ax.grid(color='#e8edf3',linewidth=.4)
fig.suptitle('C124 circuit trial • native B-side before / after',fontsize=20,fontweight='bold',y=.92)
fig.text(.5,.865,'Both panels retain board X/Y orientation. Native copper, physical holes, reference ink, Fab and courtyard graphics.',ha='center',fontsize=10)
ks=['USB_DVDT','USB_DVDT_CAP','USB_OVLO','USB_UVLO','USB_ILM','GND'];fig.legend([Patch(color=pal[k]) for k in ks],['DVDT before R125','CAP after R125','OVLO','UVLO','ILM','GND'],loc='lower center',ncol=6,bbox_to_anchor=(.5,.17),frameon=False)
fig.text(.5,.135,'9,750 tracks / 918 vias / 383 footprints / 13,185.28691027245 mm',ha='center',fontsize=11)
fig.text(.5,.105,'DRC: 0 hard / 64 warnings / 12 opens. ERC: 0. Parity: 0. Warnings: 5 removed / 3 new support-end warnings.',ha='center',fontsize=10)
fig.text(.5,.065,'UNSELECTED: native checks do not establish assembly, active startup, noise, pulse/reset, or hardware qualification.',ha='center',color='#a33330',fontsize=11)
fig.subplots_adjust(top=.82,bottom=.23,left=.06,right=.98,wspace=.11)
p=R/'qa/local-before-after-unselected.png';fig.savefig(p,dpi=180);print(p,hashlib.sha256(p.read_bytes()).hexdigest())

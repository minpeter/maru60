from pathlib import Path
import pcbnew as p,json,hashlib,math
R=Path('/tmp/v7-c124-d-actual');P=R/'filled/pcb/maru60.kicad_pcb';b=p.LoadBoard(str(P));f={q.GetReference():q for q in b.GetFootprints()};out={}
for ref in ['C124','R121','R125']:
 items=[q for q in f[ref].GraphicalItems() if q.GetLayer()==p.B_CrtYd]
 assert len(items)==1 and items[0].GetShape()==p.S_RECT
 q=items[0];s=q.GetStart();e=q.GetEnd();bb=[min(s.x,e.x)/1e6,min(s.y,e.y)/1e6,max(s.x,e.x)/1e6,max(s.y,e.y)/1e6]
 out[ref]={'centerline_bounds_mm':bb,'graphic_line_width_mm':q.GetWidth()/1e6,'graphic_uuid':q.m_Uuid.AsString()}
def gap(a,b):return math.hypot(max(0,a[0]-b[2],b[0]-a[2]),max(0,a[1]-b[3],b[1]-a[3]))
r={'actual_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),'full_uneroded_courtyard_rectangles':out,'full_boundary_pair_gaps_mm':{},'note':'KiCad cached courtyard contours used in actual-clearance-envelope.json are inset 0.005 mm per contour. They report 0.040 mm, whereas the full explicit boundary is 0.030 mm. These are geometry margins, not manufacturing tolerances or assembly qualification. Graphical line stroke width is not the courtyard boundary.'}
for pair in [('C124','R121'),('C124','R125'),('R121','R125')]:r['full_boundary_pair_gaps_mm']['/'.join(pair)]=gap(out[pair[0]]['centerline_bounds_mm'],out[pair[1]]['centerline_bounds_mm'])
(R/'qa/actual-full-courtyard-note.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))

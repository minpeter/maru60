from pathlib import Path
import pcbnew as p,json,hashlib,time,collections
R=Path('/tmp/v7-c124-d-actual');Q=R/'filled/pcb/maru60.kicad_pcb';sha=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();before=sha(Q);b=p.LoadBoard(str(Q));assert p.Version()=='9.0.2';contract=json.loads((R/'BUILD_CONTRACT.json').read_text());idx={t.m_Uuid.AsString():t for t in b.GetTracks()};fps={f.GetReference():f for f in b.GetFootprints()}
for r in contract['added_tracks']:
 t=idx[r['uuid']];assert t.GetNetname()==r['net'];assert [t.GetStart().x/1e6,t.GetStart().y/1e6]==r['start'];assert [t.GetEnd().x/1e6,t.GetEnd().y/1e6]==r['end'];assert t.GetWidth()/1e6==r['width']
for ref,v in contract['parts'].items():
 f=fps[ref];assert [f.GetPosition().x/1e6,f.GetPosition().y/1e6]==v['at'];assert f.GetValue()==v['value']
 for q in f.Pads():
  row=next(r for r in v['pads']if r[0]==q.GetNumber());assert q.GetNetname()==row[-1];assert q.IsOnLayer(p.B_Cu) and not q.IsOnLayer(p.F_Cu)
inv={'tracks':sum(not isinstance(t,p.PCB_VIA)for t in idx.values()),'vias':sum(isinstance(t,p.PCB_VIA)for t in idx.values()),'footprints':len(fps),'pads':sum(len(list(f.Pads()))for f in fps.values()),'total_track_length_mm':sum(t.GetLength()/1e6 for t in idx.values()if not isinstance(t,p.PCB_VIA)),'native_version':p.Version(),'new_parts':{ref:{'value':fps[ref].GetValue(),'position_mm':[fps[ref].GetPosition().x/1e6,fps[ref].GetPosition().y/1e6],'pads':[{'number':q.GetNumber(),'net':q.GetNetname(),'at':[q.GetPosition().x/1e6,q.GetPosition().y/1e6],'size':[q.GetSize().x/1e6,q.GetSize().y/1e6],'layers':[b.GetLayerName(l)for l in q.GetLayerSet().Seq()]}for q in fps[ref].Pads()]}for ref in contract['parts']}}
(R/'qa/prefill-native-inventory.json').write_text(json.dumps(inv,indent=2));print('NATIVE_LOADED',before,inv['tracks'],inv['vias'],flush=True);start=time.monotonic();b.BuildConnectivity();p.ZONE_FILLER(b).Fill(b.Zones());p.SaveBoard(str(Q),b);res={'prefill_sha256':before,'filled_sha256':sha(Q),'seconds':time.monotonic()-start,'zone_count':len(b.Zones()),'status':'UNSELECTED saved native refill; validation pending'};(R/'qa/native-fill.json').write_text(json.dumps(res,indent=2));print(json.dumps(res),flush=True)

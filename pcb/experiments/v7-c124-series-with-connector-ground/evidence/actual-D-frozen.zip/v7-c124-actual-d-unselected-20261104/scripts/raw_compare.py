from pathlib import Path
import sys,re,json,hashlib,collections
from sexpr_spans import *
R=Path('/tmp/v7-c124-d-actual');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();bc=json.loads((R/'BUILD_CONTRACT.json').read_text())
def index(q):
 s=q.read_text();out={};other=[]
 for a,z,t in children(s):
  m=re.search(r'\(uuid "([^"]+)"\)',t)
  if m:assert m.group(1)not in out;out[m.group(1)]=t
  else:other.append(t)
 return out,other
s,so=index(R/'source/pcb/maru60.kicad_pcb');p,po=index(R/'prefill/pcb/maru60.kicad_pcb');c,co=index(R/'filled/pcb/maru60.kicad_pcb');norm=lambda t:re.sub(r'\s+',' ',t).strip()
ret=set(bc['retired_track_uuids']);adds={t['uuid']for t in bc['added_tracks']}|{bc['parts']['R125']['uuid']};changed=set(bc['changed_old_footprint_uuids']);result={}
for n,d,o in [('prefill',p,po),('filled',c,co)]:
 removed=set(s)-set(d);added=set(d)-set(s);diff=[u for u in set(s)&set(d)if s[u]!=d[u]];structdiff=[u for u in set(s)&set(d)if norm(s[u])!=norm(d[u])];zones=[u for u in s if head(s[u])=='zone'];oldtracks=[u for u in s if head(s[u])in['segment','via','arc']and u not in ret];r={'source_sha':sha(R/'source/pcb/maru60.kicad_pcb'),'candidate_sha':sha(R/(n if n=='prefill'else'filled')/'pcb/maru60.kicad_pcb'),'removed':sorted(removed),'added':sorted(added),'raw_changed_old':diff,'structurally_changed_old':structdiff,'retirement_exact':removed==ret,'addition_exact':added==adds,'changed_old_exact':set(structdiff)==changed,'zone_count':len(zones),'zones_all_byte_exact':all(s[u]==d[u]for u in zones),'retained_track_via_count':len(oldtracks),'retained_tracks_vias_all_byte_exact':all(s[u]==d[u]for u in oldtracks),'nonuuid_structural_delta':{'removed':[x for x in so if norm(x)not in list(map(norm,o))],'added':[x for x in o if norm(x)not in list(map(norm,so))]}}
 assert r['retirement_exact']and r['addition_exact']and r['changed_old_exact'];result[n]=r
(R/'qa/raw-object-delta.json').write_text(json.dumps(result,indent=2));print(json.dumps({n:{k:v for k,v in r.items()if k not in ['removed','added','raw_changed_old','structurally_changed_old']}for n,r in result.items()},indent=2))

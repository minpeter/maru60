from pathlib import Path
import pcbnew as p,json,hashlib
R=Path('/tmp/v7-c124-d-actual');BP=R/'filled/pcb/maru60.kicad_pcb';H=lambda q:hashlib.sha256(q.read_bytes()).hexdigest();SHA=H(BP);assert SHA=='f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b';b=p.LoadBoard(str(BP));items=list(b.GetTracks())+[q for f in b.GetFootprints()for q in f.Pads()];uid=lambda q:q.m_Uuid.AsString();idx={uid(q):q for q in items};A=json.loads((R/'qa/actual-local-material.json').read_text());S=json.loads((R/'qa/source-local-material.json').read_text());C=json.loads(Path('/tmp/v7-c124-c-actual/qa/actual-local-material.json').read_text());B=json.loads((R/'BUILD_CONTRACT.json').read_text());SC=json.loads(Path('/tmp/v7-r121-rn73r-local-study/revision3/SCREEN.json').read_text());CONTACT=json.loads((R/'qa/actual-contact-reference.json').read_text())
def load(rows):
 q=p.SHAPE_POLY_SET()
 for row in rows:
  z=p.SHAPE_LINE_CHAIN()
  for x,y in row['outer']:z.Append(x,y)
  z.SetClosed(True);n=q.AddOutline(z)
  for ring in row['holes']:
   z=p.SHAPE_LINE_CHAIN()
   for x,y in ring:z.Append(x,y)
   z.SetClosed(True);q.AddHole(z,n)
 return q
def cross(a,z):
 q=p.SHAPE_POLY_SET();q.BooleanIntersection(a,z);return q
def poly(sh,out=False):
 q=p.SHAPE_POLY_SET();sh.TransformToPolygon(q,1,p.ERROR_OUTSIDE if out else p.ERROR_INSIDE);q.Simplify();return q
AM={q['uuid']:load(q['metal_B'])for q in A['nodes']};SM={q['uuid']:load(q['metal_B'])for q in S['nodes']};CM={q['uuid']:load(q['metal_B'])for q in C['nodes']};AN={q['uuid']:q for q in A['nodes']};holes=[load(h['polygon'])for h in A['all_physical_holes']];planes={l:load(a)for l,a in A['inner_planes'].items()}
# Full c770 source boundary support plus the explicitly preserved current-C lower OVLO boundary.
rows=[dict(source='original',old=r['old'],retained_target=r['retained'],net=r['net'])for r in CONTACT['external_source_contact_support']];rows +=[r for r in SC['source_support']if r['source']=='current'];proof=[]
for row in rows:
 m=SM if row['source']=='original'else CM;old=cross(m[row['old']],m[row['retained_target']]);target=idx[row['retained_target']];replacement=p.SHAPE_POLY_SET()
 for u,a in AM.items():
  if AN[u]['net']==row['net']and u!=row['retained_target']:replacement.BooleanAdd(a)
 missing=p.SHAPE_POLY_SET(old);missing.BooleanSubtract(replacement);expanded=p.SHAPE_POLY_SET(old);expanded.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);eroded=p.SHAPE_POLY_SET(replacement);eroded.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);expanded.BooleanSubtract(eroded);proof.append({'source':row['source'],'old':row['old'],'target':row['retained_target'],'net':row['net'],'old_area_mm2':old.Area()/1e12,'missing_mm2':missing.Area()/1e12,'missing_contours':missing.OutlineCount(),'expanded_old_minus_eroded_new_mm2':expanded.Area()/1e12,'strong_missing_contours':expanded.OutlineCount()})
newids={q['uuid']for q in B['added_tracks']}|{uid(q)for f in b.GetFootprints()if f.GetReference()in['C124','R121','R125']for q in f.Pads()};ref=[]
for u in newids:
 q=idx[u]
 if q.GetNetname()=='GND':continue
 sh=poly(q.GetEffectiveShape(p.B_Cu),True);sh.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1)
 for layer,plane in planes.items():
  d=p.SHAPE_POLY_SET(sh);d.BooleanSubtract(plane);ref.append({'uuid':u,'net':q.GetNetname(),'layer':layer,'outward_2nm_deficit_mm2':d.Area()/1e12,'contours':d.OutlineCount()})
ordinary=[]
for f in b.GetFootprints():
 if f.GetReference()not in['C124','R121','R125']:continue
 for q in f.Pads():
  sh=q.GetEffectiveShape(p.B_Cu);vs=sorted([{'via':uid(z),'net':z.GetNetname(),'gap_mm':sh.GetClearance(z.GetEffectiveShape(p.B_Cu))/1e6}for z in items if isinstance(z,p.PCB_VIA)],key=lambda r:r['gap_mm']);ordinary.append({'ref':f.GetReference(),'pad':q.GetNumber(),'uuid':uid(q),'net':q.GetNetname(),'nearest':vs[:3]})
# Explicit replacement audit: R121 old custom pad/first-OVLO contact was jointly retired,
# so the old C/V4 pad-contact patch is not incorrectly treated as a retained boundary.
allowed={'old_V4_edge':['23d58e5b-5d75-550d-a5e5-c3f826ce5769','2ceda713-c41e-4c74-9962-f6a642f1e236'],'disposition':'Old V4 first-OVLO track was already replaced in C; current C first two OVLO tracks and R121 pad geometry are expressly changed by the frozen D contract. This is an internal affected-to-affected contact, not an unchanged terminal boundary. Full original c770 external support and actual currentC lower OVLO boundary are tested above.'}
res={'actual_sha256':SHA,'source_sha256':S['sha256'],'contract_sha256':H(R/'CONSTRUCTION_INPUT_CONTRACT.json'),'all_original_external_plus_C_boundary_support':proof,'strong_outward_reference':ref,'ordinary_pad_via_outer':ordinary,'ordinary_pad_via_failures':[q for q in ordinary if q['nearest'][0]['gap_mm']<.20],'source_support_failures':[q for q in proof if q['missing_mm2']or q['missing_contours']or q['expanded_old_minus_eroded_new_mm2']or q['strong_missing_contours']],'reference_failures':[q for q in ref if q['outward_2nm_deficit_mm2']or q['contours']],'explicit_internal_R121_replacement':allowed,'qualification':False,'source_unchanged':H(BP)==SHA};(R/'qa/actual-strong-support-reference.json').write_text(json.dumps(res,indent=2)+'\n');print(json.dumps({'supports':len(proof),'support_failures':res['source_support_failures'],'references':len(ref),'reference_failures':res['reference_failures'],'ordinary_min':min(q['nearest'][0]['gap_mm']for q in ordinary),'ordinary_failures':res['ordinary_pad_via_failures']},indent=2))

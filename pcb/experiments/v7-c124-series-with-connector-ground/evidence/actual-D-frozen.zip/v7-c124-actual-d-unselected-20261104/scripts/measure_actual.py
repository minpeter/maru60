from pathlib import Path
import json,math,pcbnew as p,hashlib
R=Path('/tmp/v7-c124-d-actual');BP=R/'filled/pcb/maru60.kicad_pcb';S=hashlib.sha256(BP.read_bytes()).hexdigest();b=p.LoadBoard(str(BP));B=json.loads((R/'BUILD_CONTRACT.json').read_text());F={f.GetReference():f for f in b.GetFootprints()};items=list(b.GetTracks())+[q for f in F.values()for q in f.Pads()];uid=lambda q:q.m_Uuid.AsString();idx={uid(q):q for q in items};newids={q['uuid']for q in B['added_tracks']}|{uid(q)for r in['C124','R125','R121']for q in F[r].Pads()};names={q['uuid']:q['name']for q in B['added_tracks']};names.update({uid(q):r+'.'+q.GetNumber()for r in['C124','R125','R121']for q in F[r].Pads()});vec=lambda a:p.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6));win=p.BOX2I(vec([10,12]),vec([14,13]));local=[q for q in items if win.Intersects(q.GetBoundingBox())];sh=lambda q:q.GetEffectiveShape(p.B_Cu)
def rect(x,y,w,h):return p.SHAPE_RECT(vec([x-w/2,y-h/2]),round(w*1e6),round(h*1e6))
def envelope(x,y,ang,lo,hi,w,sign):
 pts=[]
 for xx in[sign*lo,sign*hi]:
  for yy in[-w,w]:
   for a in[ang-2,ang,ang+2]:
    a=math.radians(a);pts.append((math.cos(a)*xx-math.sin(a)*yy,math.sin(a)*xx+math.cos(a)*yy))
 x0=math.floor((min(q[0]for q in pts)-.1)*1e6)/1e6;x1=math.ceil((max(q[0]for q in pts)+.1)*1e6)/1e6;y0=math.floor((min(q[1]for q in pts)-.1)*1e6)/1e6;y1=math.ceil((max(q[1]for q in pts)+.1)*1e6)/1e6
 return rect(x+(x0+x1)/2,y+(y0+y1)/2,x1-x0,y1-y0),[x+x0,y+y0,x+x1,y+y1]
terms=[]
for r,lo,hi,w,ang in [('C124',.125,.525,.275,0),('R125',.175,.55,.275,0),('R121',.125,.55,.275,90)]:
 f=F[r];x,y=f.GetPosition().x/1e6,f.GetPosition().y/1e6
 for sign in[-1,1]:
  num=('1'if sign<0 else'2')if r=='C124'else('1'if sign>0 else'2');q=next(q for q in f.Pads()if q.GetNumber()==num);ss,bb=envelope(x,y,ang,lo,hi,w,sign);terms.append((r,num,q.GetNetname(),ss,bb))
checks=[]
for u in sorted(newids):
 q=idx[u];c=sh(q);foreign=sorted([{'uuid':uid(t),'net':t.GetNetname(),'gap_mm':c.GetClearance(sh(t))/1e6}for t in local if t.IsOnLayer(p.B_Cu)and t.GetNetname()!=q.GetNetname()],key=lambda r:r['gap_mm']);drills=sorted([{'uuid':uid(t),'net':t.GetNetname(),'gap_mm':c.GetClearance(t.GetEffectiveHoleShape())/1e6}for t in local if isinstance(t,(p.PAD,p.PCB_VIA))and t.HasHole()],key=lambda r:r['gap_mm']);te=sorted([{'reference':r,'pad':n,'net':net,'gap_mm':c.GetClearance(s)/1e6}for r,n,net,s,bb in terms if net!=q.GetNetname()and not names[u].startswith(r)],key=lambda r:r['gap_mm']);checks.append({'uuid':u,'name':names[u],'foreign':foreign[:3],'drills':drills[:3],'terminal_envelopes':te})
termchecks=[]
for r,n,net,s,bb in terms:
 fs=sorted([{'uuid':uid(q),'net':q.GetNetname(),'gap_mm':s.GetClearance(sh(q))/1e6}for q in local if q.IsOnLayer(p.B_Cu)and q.GetNetname()!=net and not(isinstance(q,p.PAD)and q.GetParentFootprint().GetReference()==r)],key=lambda x:x['gap_mm']);termchecks.append({'ref':r,'pad':n,'net':net,'bounds':bb,'nearest_foreign':fs[:3]})
courts=[]
for r in['C124','R125','R121']:
 f=F[r];f.BuildCourtyardCaches();cs=f.GetCourtyard(p.B_CrtYd);rows=[]
 for ref,z in F.items():
  if ref==r:continue
  z.BuildCourtyardCaches();zs=z.GetCourtyard(p.B_CrtYd)
  if zs.OutlineCount()and zs.BBox().Intersects(win):rows.append({'ref':ref,'gap_mm':cs.GetClearance(zs)/1e6})
 courts.append({'ref':r,'nearest_courts':sorted(rows,key=lambda x:x['gap_mm'])[:6]})
lengths={}
for q in B['added_tracks']:
 group='GROUND_BRIDGES'if q['name'].startswith('GROUND')else''.join(x for x in q['name']if not x.isdigit());lengths[group]=lengths.get(group,0)+idx[q['uuid']].GetLength()/1e6
res={'sha256':S,'actual_checks':checks,'terminal_to_actual_copper':termchecks,'courts':courts,'route_lengths_mm':lengths,'actual_copper_foreign_failures':[q for q in checks if q['foreign'][0]['gap_mm']<.15],'actual_terminal_copper_failures':[q for q in termchecks if q['nearest_foreign'][0]['gap_mm']<.15],'manufacturer_occupied_area_conflict_mm':0,'manufacturer_note':'C124 actual board/module court is explicit maximum occupied1.90×1.10; actual clearance must pass while manufacturer-process and assembly qualification remain false.','qualification':False};(R/'qa/actual-clearance-envelope.json').write_text(json.dumps(res,indent=2));print(json.dumps({'copper_fail':[(r['name'],r['foreign'][0])for r in res['actual_copper_foreign_failures']],'terminal_fail':res['actual_terminal_copper_failures'],'lengths':lengths,'courts':courts},indent=2))

from pathlib import Path
import json,hashlib,shutil,zipfile
R=Path('/tmp/v7-c124-d-actual');H=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert H(R/'filled/pcb/maru60.kicad_pcb')=='f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b'
assert H(Path('/tmp/v7-c124-d-independent-review/MANIFEST.json'))=='6bd560d0fce149f914d797dce2c17adbd246f618e59c8a0b038f00749d7373b9'
shutil.copytree('/tmp/v7-c124-d-independent-review',R/'reviews/actual-independent',dirs_exist_ok=True)
ps=R/'inputs/part-sources';ps.mkdir(exist_ok=True)
for name in ['UPY-C_GEN_25.pdf','CC0402KRX7R9BB103-official.pdf']:
 shutil.copy2(Path('/tmp/v7-c124-joint-two-net-study/part-sources')/name,ps/name)
# Keep the originally executed scripts unchanged; map their historical absolute input paths to archived bytes.
mapping={
 '/tmp/v7-c124-c-actual/filled/pcb':'inputs/C-filled-pcb',
 '/tmp/v7-c124-c-actual/BUILD_CONTRACT.json':'inputs/C-BUILD_CONTRACT.json',
 '/tmp/v7-c124-c-actual/qa/actual-local-material.json':'inputs/C-local-material.json',
 '/tmp/v7-c124-joint-two-net-study/native-inventory.json':'inputs/historical-V4-native-inventory.json',
 '/tmp/v7-r121-rn73r-local-study':'inputs/rn73r-construction-study',
 '/tmp/v7-c124-joint-two-net-study/part-sources/UPY-C_GEN_25.pdf':'inputs/part-sources/UPY-C_GEN_25.pdf',
 '/tmp/v7-c124-joint-two-net-study/part-sources/CC0402KRX7R9BB103-official.pdf':'inputs/part-sources/CC0402KRX7R9BB103-official.pdf',
 '/tmp/v7-c124-d-binding-review':'reviews/component-binding',
 '/tmp/v7-c124-d-independent-review':'reviews/actual-independent'}
(R/'REPLAY_INPUT_MAP.json').write_text(json.dumps({'note':'Scripts are preserved as executed, including original absolute paths. Reproduction in another directory must map these archived inputs explicitly and write only fresh replay outputs. Source/prefill/filled files are immutable evidence, not replay destinations. No replay fixed-point claim is made.','absolute_to_packet_relative':mapping},indent=2)+'\n')
p=R/'RESULT.md';s=p.read_text().replace('- Separate actual raw/R2/support/reference and plotted mask/paste review is supplied under `reviews/actual-independent/` with its own manifest when sealed. It uses the existing corrected material export, not a duplicate graph.','- Separate actual raw/R2/support/reference and plotted mask/paste review: all **33 independent checks pass**. `reviews/actual-independent/` has its own manifest SHA 6bd560d0fce149f914d797dce2c17adbd246f618e59c8a0b038f00749d7373b9. All six effective plotted apertures match intended rectangles; the conservative target-to-any-other-aperture separation is at least .50 mm. No duplicate graph or additional independent cold refill was performed. Three native endpoint warnings remain recorded without automatic acceptance or adoption.')
p.write_text(s)
status={'status':'COMPLETED UNSELECTED CONSTRUCTION CHECKPOINT; not selected or qualified','source_sha256':H(R/'source/pcb/maru60.kicad_pcb'),'prefill_sha256':H(R/'prefill/pcb/maru60.kicad_pcb'),'filled_sha256':H(R/'filled/pcb/maru60.kicad_pcb'),'construction_contract_sha256':H(R/'CONSTRUCTION_INPUT_CONTRACT.json'),'filled_tree_files':58,'filled_tree_manifest_sha256':H(R/'FILLED_TREE_MANIFEST.json'),'native':{'tracks':9750,'vias':918,'footprints':383,'track_length_mm':13185.28691027245,'hard_errors':0,'warnings':64,'opens':12,'ERC':0,'parity':0},'warnings':{'old_retired':5,'new_native_endpoint':3,'new_accepted_or_suppressed':False},'gates':{'raw_source_delta':True,'all_retained_track_via_records_exact':True,'all_12_zones_exact':True,'all_1269_physical_holes_exact':True,'all_net_partition_contract':True,'no_resistor_bypass':True,'all_14_full_boundary_supports_plus2_minus2_nm':True,'all_58_outward2nm_reference_projections':True,'zero_added_old_reference_shadow_loss':True,'ordinary_pad_via_020mm':True,'actual_foreign_copper':True,'actual_terminal_envelopes':True,'actual_full_courtyards':True,'component_schematic_BOM_module_binding_223_checks':True,'independent_actual_33_checks':True,'effective_mask_paste_apertures':True},'historical_diagnostic':'Internal obsolete V4 R121 pad/first-OVLO contact is explicitly replaced; diagnostic remains in original receipt. No unchanged-boundary support is waived.','existing_material_guard_failures_unchanged':51,'qualification':{'adoption':False,'assembly':False,'manufacturer_process':False,'procurement':False,'switch_socket_plate_case':False,'active_startup':False,'analog_parasitics_noise':False,'pulse_reset':False,'hardware':False,'RN73R_TNPW_long_term_equivalence':False},'remaining_native_conditions':'Twelve exact existing opens and three added support-end warnings remain. No native-warning waiver or automatic adoption.','independent_actual_manifest_sha256':H(R/'reviews/actual-independent/MANIFEST.json'),'passive_packet_sha256':H(R/'reviews/v7-c124-d-passive-binding-20261104.zip')}
(R/'STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
# Verify all three complete native project maps and independent review member hashes where recorded.
for dirname,mapname in [('source','SOURCE_TREE_MANIFEST.json'),('prefill','PREFILL_TREE_MANIFEST.json'),('filled','FILLED_TREE_MANIFEST.json')]:
 d=json.loads((R/mapname).read_text());assert len(d['files'])==d['count']
 for q in d['files']:assert H(R/dirname/'pcb'/q['path'])==q['sha256'],(dirname,q['path'])
exclude={'MANIFEST.json','ARCHIVE_RECEIPT.json'}
files=[]
for q in sorted(R.rglob('*')):
 if not q.is_file():continue
 rel=q.relative_to(R)
 if rel.parts[0].startswith('runtime.') or 'plot-cache' in rel.parts or '__pycache__' in rel.parts or str(rel) in exclude or (len(rel.parts)==1 and q.suffix=='.zip'):continue
 files.append({'path':str(rel),'bytes':q.stat().st_size,'sha256':H(q)})
m={'status':'UNSELECTED D actual evidence packet','file_count':len(files),'files':files}
(R/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n')
Z=R/'v7-c124-actual-d-unselected-20261104.zip'
assert not Z.exists()
with zipfile.ZipFile(Z,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for q in files:z.write(R/q['path'],'v7-c124-actual-d-unselected-20261104/'+q['path'])
 z.write(R/'MANIFEST.json','v7-c124-actual-d-unselected-20261104/MANIFEST.json')
with zipfile.ZipFile(Z) as z:
 assert z.testzip() is None
 for q in files:assert hashlib.sha256(z.read('v7-c124-actual-d-unselected-20261104/'+q['path'])).hexdigest()==q['sha256']
a={'archive':str(Z),'bytes':Z.stat().st_size,'sha256':H(Z),'manifest_sha256':H(R/'MANIFEST.json'),'artifacts':len(files),'archive_entries':len(files)+1,'filled_board_sha256':H(R/'filled/pcb/maru60.kicad_pcb'),'filled_tree_manifest_sha256':H(R/'FILLED_TREE_MANIFEST.json'),'report_sha256':H(R/'RESULT.md'),'status_sha256':H(R/'STATUS.json')}
(R/'ARCHIVE_RECEIPT.json').write_text(json.dumps(a,indent=2)+'\n');print(json.dumps(a,indent=2))

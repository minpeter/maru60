from pathlib import Path
import json,pcbnew as p,collections,hashlib
R=Path('/tmp/v7-c124-d-actual');A=json.loads((R/'qa/actual-local-material.json').read_text());S=json.loads((R/'qa/source-local-material.json').read_text());B=json.loads((R/'BUILD_CONTRACT.json').read_text());source={x['uuid']:x for x in S['nodes']};actual={x['uuid']:x for x in A['nodes']}
def load(arr,factor=1):
 q=p.SHAPE_POLY_SET()
 for row in arr:
  line=p.SHAPE_LINE_CHAIN()
  for x,y in row['outer']:line.Append(round(x*factor),round(y*factor))
  line.SetClosed(True);ind=q.AddOutline(line)
  for h in row['holes']:
   line=p.SHAPE_LINE_CHAIN()
   for x,y in h:line.Append(round(x*factor),round(y*factor))
   line.SetClosed(True);q.AddHole(line,ind)
 return q

def cross(a,b):
 q=p.SHAPE_POLY_SET();q.BooleanIntersection(a,b);return q

def loss(a,b):
 q=p.SHAPE_POLY_SET(a);q.BooleanSubtract(b);return q.Area()/1e12
sm={u:load(q['metal_B'])for u,q in source.items()};am={u:load(q['metal_B'])for u,q in actual.items()};added={t['uuid']for t in B['added_tracks']};changedpads={u for u,q in actual.items()if q.get('reference')in['C124','R121','R125']};newids=added|changedpads;affected=set(B['retired_track_uuids'])|{u for u,q in source.items()if q.get('reference')in['C124','R121']};unions={}
for u in newids:
 net=actual[u]['net'];unions.setdefault(net,p.SHAPE_POLY_SET()).BooleanAdd(am[u])
bound=[];retired=[]
for e in S['edges']:
 if e['a']in affected or e['b']in affected:retired.append(e)
 if (e['a']in affected)==(e['b']in affected):continue
 old,keep=(e['a'],e['b'])if e['a']in affected else(e['b'],e['a']);sup=cross(sm[old],sm[keep]);bound.append(dict(e,old=old,retained=keep,old_support_mm2=sup.Area()/1e12,missing_in_new_metal_mm2=loss(sup,unions[e['net']])))
# V4 six control support contacts, cut every same local physical drill before comparison.
V=json.loads(Path('/tmp/v7-c124-joint-two-net-study/native-inventory.json').read_text());vi={q['uuid']:q for q in V['local_B_objects']};holes=p.SHAPE_POLY_SET()
for h in A['all_physical_holes']:
 # restrict to local box before a Boolean union so this remains a local proof
 if h['uuid']in actual:holes.BooleanAdd(load(h['polygon']))
def vm(u):
 q=load(vi[u]['copper'],1e6);q.BooleanSubtract(holes);return q
six=[]
for old in V['proposed_bounded_control_records']:
 for ct in old['contacts']:
  if ct['inside_proposed_retirement']:continue
  su=cross(vm(old['uuid']),vm(ct['uuid']));six.append({'old':old['uuid'],'retained':ct['uuid'],'net':old['net'],'old_support_mm2':su.Area()/1e12,'missing_in_actual_new_metal_mm2':loss(su,unions[old['net']])})
planes={n:load(q)for n,q in A['inner_planes'].items()};refs=[]
for u in sorted(newids):
 if actual[u]['net']=='GND':continue
 for n,plane in planes.items():refs.append({'uuid':u,'net':actual[u]['net'],'reference':actual[u].get('reference'),'layer':n,'uncovered_mm2':loss(am[u],plane)})
roots=[]
for u in ['efadf2be-e519-469f-a84c-2e7cbb60672a','763086b7-5549-4f5e-bb08-ce25387b3627','8e0fa85d-f2bc-543d-aae7-d8f6ff75061a']:
 for l,pl in planes.items():roots.append({'uuid':u,'layer':l,'contact_mm2':cross(am[u],pl).Area()/1e12})
# Pure direct physical local partitions and explicit no-bypass between resistor endpoints.
parent={u:u for u in actual}
def find(u):
 while parent[u]!=u:parent[u]=parent[parent[u]];u=parent[u]
 return u
for e in A['edges']:parent[find(e['a'])]=find(e['b'])
pads={(q.get('reference'),q.get('number')):u for u,q in actual.items()if q['kind']=='PAD'};r1=pads['R125','1'];r2=pads['R125','2'];c1=pads['C124','1'];c2=pads['C124','2'];u8=pads['U8','7'];gr='8e0fa85d-f2bc-543d-aae7-d8f6ff75061a';chain={'U8.7_to_R125.1':find(u8)==find(r1),'R125.2_to_C124.1':find(r2)==find(c1),'C124.2_to_existing_GND_via':find(c2)==find(gr),'no_R125_copper_bypass':find(r1)!=find(r2),'no_cap_to_ground_short':find(c1)!=find(c2)}
# Every foreign-net intersection in the local material is checked independently of net-filtered graph.
shorts=[]
ns=list(actual)
for i,u in enumerate(ns):
 for v in ns[i+1:]:
  if actual[u]['net']==actual[v]['net']or not am[u].BBox().Intersects(am[v].BBox()):continue
  ar=cross(am[u],am[v]).Area()/1e12
  if ar>0:shorts.append({'a':u,'b':v,'area_mm2':ar})
result={'source_sha':S['sha256'],'actual_sha':A['sha256'],'source_affected_contacts':retired,'external_source_contact_support':bound,'V4_six_control_contact_support':six,'new_reference_projections':refs,'root_contacts':roots,'all_physical_holes_exact':S['all_physical_holes']==A['all_physical_holes'],'physical_holes_count':len(A['all_physical_holes']),'direct_circuit_order':chain,'foreign_local_shorts':shorts,'new_to_retained_edges':[e for e in A['edges']if (e['a']in newids)!=(e['b']in newids)],'new_to_new_edges':[e for e in A['edges']if e['a']in newids and e['b']in newids]}
# canonical list order can change across SaveBoard; compare by UUID in addition.
result['all_physical_holes_by_uuid_exact']={q['uuid']:q for q in S['all_physical_holes']}=={q['uuid']:q for q in A['all_physical_holes']}
(R/'qa/actual-contact-reference.json').write_text(json.dumps(result,indent=2));print(json.dumps({'external_support_count':len(bound),'external_support_failures':[x for x in bound if x['missing_in_new_metal_mm2']>0],'V4_six_support_failures':[x for x in six if x['missing_in_actual_new_metal_mm2']>0],'new_reference_deficits':[x for x in refs if x['uncovered_mm2']>0],'roots':roots,'circuit':chain,'foreign_shorts':shorts,'all_holes_exact_by_uuid':result['all_physical_holes_by_uuid_exact']},indent=2))

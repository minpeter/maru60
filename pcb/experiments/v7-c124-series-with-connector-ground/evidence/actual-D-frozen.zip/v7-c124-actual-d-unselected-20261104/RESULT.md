# C124 D: actual circuit trial, UNSELECTED

**The bounded construction and actual native/material checks pass. The candidate is not selected and is not assembly, hardware, pulse/reset, noise, or active-startup qualified.** The selected source and earlier C trial remain unchanged.

## Exact source and actual tree

- Selected construction source: c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a, repository commit 094851aa91eb49e40182c9a88657a8ed6e6dcba8.
- Frozen input contract: 15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd.
- Prefill: a07cc6b2e6bfa33616e2cd712a272e13c134399def9cfa55ce2bf3532663034b.
- Filled candidate: **f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b**, `filled/pcb/maru60.kicad_pcb`.
- The complete actual project has 58 files, listed in `FILLED_TREE_MANIFEST.json`. Source and prefill have separate maps. No selected-entrypoint or Git change was made.

## Constructed circuit and bounded delta

The actual native physical graph and schematic XML agree: **U8.7 → R125 100 Ω → C124 10 nF → existing rooted GND**, with no copper resistor bypass or CAP-to-GND short. Both physical U8.7 pads remain represented in the native partition. Divider logical connectivity and nominal values remain unchanged.

The exact source-relative change is 31 named old track retirements, 31 new tracks, changed C124/R121 footprints, added R125 and USB_DVDT_CAP net. All 10,637 retained native tracks/vias are byte-exact. All other old footprints/settings are unchanged. The two remote GND deletions and earlier BUCK cleanup remain absent. There are no new drills; all 918 vias and 351 footprint holes are identical.

Compared with C, the local contract replaces exactly two C-added OVLO tracks with the ten declared tracks, changes the R121 package and C124 pose/courtyard, and carries the two selected remote GND deletions. R125 is wholly unchanged. The detailed UUID ledger is in `BUILD_CONTRACT.json`, not inferred from this summary.

- R121: proposed KOA RN73R1ETTP1563B25, 156 kΩ ±0.1%, ±25 ppm/K, 0402, center (13.68,18.65), vertical. Global .30×.40 mm pads at .90 mm pitch, explicit 1.05×1.80 mm courtyard.
- C124: proposed YAGEO CC0402KRX7R9BB103, 10 nF ±10%, 50 V X7R, center (15.185,19.375). .50×.50 mm lands at 1.00 mm pitch, explicit **1.90×1.10 mm maximum occupied courtyard** in both board and supplied project module.
- R125: proposed KOA RK73H1ETTP1000F, 100 Ω ±1%, center (15.36,20.48), .40×.30 mm lands at .90 mm pitch.

The initial-value/TCR identity of RN73R is not a claim of equivalent endurance/humidity drift to the earlier TNPW proposal. R120's MPN/TCR/thermal tracking remains unknown. All three part identities are experimental BOM changes, not procurement selections.

## Native results and warnings

Normal native refill completed in 2.317222691 seconds. The actual same-snapshot inventory is **9,750 tracks / 918 vias / 383 footprints / 13,185.28691027245 mm**. DRC has **0 hard errors, 64 warnings, 12 opens, parity 0**; ERC has **0 violations**. The twelve raw open records are exactly the source records.

The source has 66 warnings. Five old C124/R121 reference-size/mask/silk warnings retire; three new endpoint-dangling warnings remain on the deliberate support restorations `f58bc791…` (GND), `cc1282fe…` (OVLO) and `d4be2091…` (UVLO). Their complete copper is joined by positive 2 nm guarded contacts and has the correct physical net roots. The endpoint warnings are retained, not suppressed or silently deleted. Exact records and material witnesses: `qa/drc-warning-delta.json`.

The corrected R2 checker SHA is 57987368b095de525fc729a0d4b729b14cfc207afd07b4bd214ee5463a7719b9. Its single actual export is `qa/actual-material-graph.json`, SHA 2d4b25e398e2d635de747a696dd263ef1f83b638001a4beec4932583b1e4f98a. All unintended pad-partition changes are zero. The 51 pre-existing material-guard failures are unchanged; none are hidden, newly introduced or waived.

## Full original support and reference preservation

All **13 original selected external boundary patches**, including the complete old C124 and R121 GND support regions, are preserved with zero missing material. The additional C-relative lower OVLO boundary also passes. All **14 patches** pass both exact inclusion and expanded-old/eroded-new 2 nm tests. All **58** new non-GND projections pass outward 2 nm coverage on both actual inner planes. The three existing local GND via annuli independently contact both planes.

All twelve serialized filled zones are byte-exact to c770 after refill. Together with unchanged physical holes, this proves zero additional inner-plane loss and zero additional loss under every old reference projection, including retired objects. It does not assert that every pre-existing reference shadow was perfect.

The inherited historical V4 diagnostic for the old first OVLO track→R121.1 pad reports 0.0657741469075 mm² absent from the new metal. That was an **internal affected-to-affected contact**: the track was replaced in C and its later C descendants plus the R121 pad are explicitly replaced by D. It is not an unchanged boundary and is not relabeled preserved. The original selected external contacts and the current-C retained lower boundary are separately preserved in full. See `qa/actual-strong-support-reference.json`.

## Actual geometry and manufacturing limits

No new/changed foreign-copper clearance failures or conservative terminal/solder-envelope failures were found. The minimum new copper clearance is .160000 mm. The narrowest modeled terminal-envelope-to-foreign-copper gap is .157494 mm, against the unchanged .150 mm criterion. The ordinary outer pad-to-via gap, including same-net GND, is at least .266575 mm against the .200 mm gate.

Full, un-eroded C124 maximum occupied boundaries leave **.030 mm** to each of R121 and R125 courtyards. KiCad's cached contours are inset .005 mm each and report .040 mm; that larger value is not the full-boundary margin. `qa/actual-full-courtyard-note.json` records native rectangle endpoints and this distinction. The former C trial's manufacturer occupied-width conflict is not waived; D explicitly uses the larger 1.90×1.10 mm boundary and changes the part/pose to clear it.

The YAGEO land/occupied-area recommendation is historical general family guidance, not a current exact-part process approval. Current exact-part dimensions and the modeled ±2° rotation, ±.05 mm placement and .05 mm solder allowance remain explicitly distinguished. Nominal mask/paste aperture geometry does not certify registration, stencil volume, reflow, socket/plate/keycap fit or production yield.

## Route witnesses and electrical limitations

Actual main pin-side DVDT centerline is 1.925226953375 mm of new tracks plus .035355339059 mm retained source stub, **1.960582292434 mm total**. CAP track is **1.090366910723 mm**; capacitor return track is **.699231721248 mm**. Support tracks intentionally overlap the main route; their centerline sums are not extra unique series path length. UVLO replacement main chain is 9.436568489413 mm; the independent complete OVLO arm witness is 10.414184183 mm.

The independent nominal/passive packet is included unchanged in `reviews/v7-c124-d-passive-binding-20261104.zip`, SHA **d763ad67082493ef71399513d1665029f8e2ecbe3421b951d056426674005cb5**. It binds actual parts, native geometry and XML, and freshly replays 36 existing hypothetical passive cases. It does not extract D-specific parasitics or establish a noise improvement. Actual capacitor bias/temperature/aging, resistor pulse/reset behavior, eFuse active startup/brownout, ESD/EMC, fault/transient maxima, assembly and hardware remain unqualified.

## Independent checks and images

- Component/schematic/BOM/module review: all 223 checks pass. All 1,064 named native/XML pin assignments and all XML nets match the intended circuit. `reviews/component-binding/` contains the unchanged review.
- Separate actual raw/R2/support/reference and plotted mask/paste review: all **33 independent checks pass**. `reviews/actual-independent/` has its own manifest SHA 6bd560d0fce149f914d797dce2c17adbd246f618e59c8a0b038f00749d7373b9. All six effective plotted apertures match intended rectangles; the conservative target-to-any-other-aperture separation is at least .50 mm. No duplicate graph or additional independent cold refill was performed. Three native endpoint warnings remain recorded without automatic acceptance or adoption.
- `qa/local-before-after-unselected.png` compares exact c770 with actual f987 B-side geometry and includes the actual inventory/DRC/ERC/parity/warning delta. `qa/local-top-bottom-unselected.png` shows the actual top and bottom. Both use native 100 nm display polygons, not visual DRC proofs. `qa/IMAGE_PROVENANCE.json` binds the images and raw view exports to these board hashes.

This packet preserves an actual UNSELECTED trial for review/backup. Passing bounded native gates is not production approval, and all 12 pre-existing opens remain unresolved by this circuit task.

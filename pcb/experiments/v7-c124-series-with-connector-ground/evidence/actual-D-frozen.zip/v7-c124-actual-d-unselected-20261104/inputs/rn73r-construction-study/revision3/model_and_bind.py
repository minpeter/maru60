from pathlib import Path
import sys,json,hashlib,re,collections,math
sys.dont_write_bytecode=True
D=Path('/tmp/v7-r121-rn73r-local-study/revision3');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();SC=Path('/tmp/v7-c124-c-actual/filled/pcb/maru60.kicad_pcb');A=Path('/tmp/v7-c124-c-actual/source/pcb/maru60.kicad_pcb');BASE=Path('/workspace/scratch/edd9a5be63e7/pcb-v7-recovery-20261104/pcb/experiments/v7-gnd-deadbranch-cleanup/candidate/pcb/maru60.kicad_pcb');G=Path('/tmp/v7-c124-c-actual/qa/actual-material-graph.json');S=json.loads((D/'SCREEN.json').read_text());sG=json.loads(G.read_text());assert sha(SC)==S['source_sha256']==sG['board_sha256'];assert sha(A)=='aead2fb0c61ee3cb565f03e3a271f213911767c37f47e86d0adae87735428b3f';assert sha(BASE)=='c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a'
def children(s):
 depth=0;q=False;esc=False;a=None;out=[]
 for i,c in enumerate(s):
  if q:
   if esc:esc=False
   elif c=='\\':esc=True
   elif c=='"':q=False
   continue
  if c=='"':q=True
  elif c=='(':
   depth+=1
   if depth==2:a=i
  elif c==')':
   if depth==2:out.append(s[a:i+1])
   depth-=1
 assert depth==0 and not q
 return out
def head(t):return re.match(r'\(\s*([^\s()]+)',t).group(1)
def objmap(p):
 result={};noid=[]
 for t in children(p.read_text()):
  u=next((c for c in children(t)if head(c)=='uuid'),None)
  if u:
   key=re.search(r'"([^"]+)"',u)[1];assert key not in result;result[key]=t
  else:noid.append(t)
 return result,noid
am,ah=objmap(A);bm,bh=objmap(BASE);assert ah==bh;retired=sorted(am.keys()-bm.keys());assert len(retired)==2 and {u[:8]for u in retired}=={'68f95f8e','577f36c1'};assert not bm.keys()-am.keys()and all(am[k]==bm[k]for k in bm);assert all(head(am[u])=='segment'and '(net 83)'in am[u]for u in retired)
local=json.loads(Path('/tmp/v7-c124-c-actual/qa/actual-local-material.json').read_text());local_ids={n['uuid']for n in local['nodes']};assert not local_ids.intersection(retired)
for u in retired:
 assert u in sG['object_nodes_by_layer']
# Source material graph is inherited actual-native evidence, not a newly executed whole-board export.
class DSU:
 def __init__(self,ns):self.p={n:n for n in ns}
 def root(self,x):
  while self.p[x]!=x:self.p[x]=self.p[self.p[x]];x=self.p[x]
  return x
 def join(self,a,b):
  a=self.root(a);b=self.root(b)
  if a!=b:self.p[max(a,b)]=min(a,b)
def original_dsu():
 d=DSU(sG['material_nodes'])
 for a,b,area,guard in sG['material_edges']:assert area>0 and guard>0;d.join(a,b)
 for r in sG['barrel_joins']:
  for n in r['nodes'][1:]:d.join(r['nodes'][0],n)
 return d
old=original_dsu();assert {n:old.root(n)for n in old.p}==sG['material_roots']
changed={q['uuid']for q in S['pads']};drop=changed|set(S['retire_relative_to_C'])|set(retired);name2pad={q['name']:q['uuid']for q in S['pads']};pad2name={v:k for k,v in name2pad.items()};newnet={q['name']:q['net']for q in S['pads']+S['tracks']}
def build(drop_new=(),extra_edges=()):
 deleted={n for n,m in sG['material_nodes'].items()if m.get('uuid')in drop};ns={n:m['net']for n,m in sG['material_nodes'].items()if n not in deleted};ns.update({'proposal:'+k:v for k,v in newnet.items()if k not in drop_new});d=DSU(ns)
 for a,b,area,guard in sG['material_edges']:
  if a in ns and b in ns:d.join(a,b)
 for r in sG['barrel_joins']:
  assert not set(r['nodes']).intersection(deleted),'No plated barrel may be altered'
  for n in r['nodes'][1:]:d.join(r['nodes'][0],n)
 def node(u):
  if u in newnet:return'proposal:'+u
  rr=sG['object_nodes_by_layer'][u]['B.Cu'];assert len(rr)==1;assert rr[0]in ns;return rr[0]
 accepted=[]
 for r in S['new_physical_contacts']:
  if r['a']in drop_new or r['b']in drop_new:continue
  assert r['native_area_mm2']>0 and r['guard_2nm_mm2']>0
  a,b=node(r['a']),node(r['b']);assert ns[a]==ns[b]==r['net'];d.join(a,b);accepted.append((a,b))
 for a,b in extra_edges:
  assert ns[a]==ns[b], 'Cross-net edge prohibited'
  d.join(a,b)
 return d,ns,accepted

def partitions(d,proposal=False):
 groups={}
 for u,info in sG['pad_inventory'].items():
  if not info['pad']or not info['net']:continue
  if proposal and u in changed:
   n='proposal:'+pad2name[u]
   if n not in d.p:root='MISSING:'+u
   else:root=d.root(n)
  else:
   roots={d.root(n)for layer,ns in sG['object_nodes_by_layer'][u].items()for n in ns};assert len(roots)==1;root=next(iter(roots))
  groups.setdefault(info['net'],{}).setdefault(root,[]).append(u)
 return {net:sorted(sorted(v)for v in roots.values())for net,roots in sorted(groups.items())}
oldparts=partitions(old);assert oldparts==sG['pad_partitions_by_net'];d,nn,es=build();parts=partitions(d,True);assert parts==oldparts
witnesses={}
def path(a,b):
 adj={}
 for x,y in es:adj.setdefault(x,[]).append(y);adj.setdefault(y,[]).append(x)
 Q=collections.deque([a]);prev={a:None}
 while Q:
  x=Q.popleft()
  if x==b:break
  for y in adj.get(x,[]):
   if y not in prev:prev[y]=x;Q.append(y)
 if b not in prev:return None
 out=[];x=b
 while x is not None:out.append(x);x=prev[x]
 return out[::-1]
for name,target in [('R121.2','abcd4fb1-881b-43f9-906e-39d93366692e'),('R121.1','9f71c7e9-1999-5d93-bca7-92de689f89aa'),('C124.1','14ce044c-5d14-57b8-a5b8-96edcd04f5e9'),('C124.2','94047f09-e88d-56e7-aee2-15e0dcdca1ac')]:
 targetnode=sG['object_nodes_by_layer'][target]['B.Cu'][0];witnesses[name]=path('proposal:'+name,targetnode);assert witnesses[name]
# Actual inherited GND root corroboration, separate from proposed local paths.
rootpad=next(u for u,x in sG['pad_inventory'].items()if x['ref']=='J1'and x['pad']=='A1');groundroots={old.root(n)for r in sG['object_nodes_by_layer'][rootpad].values()for n in r};assert len(groundroots)==1
for u in ['763086b7-5549-4f5e-bb08-ce25387b3627','8e0fa85d-f2bc-543d-aae7-d8f6ff75061a']:
 assert set(sG['object_material_roots'][u])==groundroots
controls=[]
for missing in ['R121_GND_LEG','R121_OVLO0','R121_OVLO1','R121_OVLO3']:
 dd,_,_=build({missing});assert partitions(dd,True)!=oldparts;controls.append({'mutation':'remove '+missing,'rejected_by_partition_difference':True})
try:build(extra_edges=[('proposal:C124.1','proposal:C124.2')])
except AssertionError:controls.append({'mutation':'CAP-to-GND forged short','rejected':True})
else:raise AssertionError('short not rejected')
dd,_,_=build({'R121_OVLO2'});assert partitions(dd,True)==oldparts
controls.append({'mutation':'remove short R121_OVLO2 elbow','positive_topology_control':True,'exact_geometry_contract_would_still_reject_missing_track':True})
result={'status':'analytical patched graph, not a freshly constructed/native-exported board','sourceC_sha256':sha(SC),'sourceC_graph_sha256':sha(G),'screen_sha256':sha(D/'SCREEN.json'),'selected_base_sha256':sha(BASE),'selected_commit':'094851aa91eb49e40182c9a88657a8ed6e6dcba8','rebase':{'source_aead_sha256':sha(A),'exact_only_raw_retirements':retired,'all_other_UUID_objects_and_nonUUID_fields_equal':True,'local_inventory_contains_retired_objects':False,'preserve_these_retirements_in_future_construction':True},'all_named_pad_partitions_equal_C':parts==oldparts,'net_group_count':len(parts),'pad_component_count':sum(len(v)for v in parts.values()),'local_new_guarded_paths':witnesses,'inherited_sourceGND_root':{'J1_A1_pad_uuid':rootpad,'root':list(groundroots)[0],'ordinary_GND_vias_proved_in_same_native_root':['763086b7-5549-4f5e-bb08-ce25387b3627','8e0fa85d-f2bc-543d-aae7-d8f6ff75061a']},'controls':controls,'no_board_load_native_execution_or_files_written_outside_review':True,'script_sha256':sha(__file__)}
(D/'MODEL_AND_REBASE.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

# R121 0402 alternative: catalog and electrical feasibility

**A bounded geometry experiment is supportable with KOA RN73R1ETTP1563B25. The suggested Vishay TNPW0402156KBEEA is not a supported standard catalog combination.** No BOM or CAD change is made or adopted by this review. The circuit remains 590 kΩ above the sense node and 156 kΩ from that node to ground.

## Exact part identity

Vishay's current [TNPW e3 datasheet](https://www.vishay.com/docs/28758/tnpw_e3.pdf), 10-Apr-2026, restricts 0402 to at most 100 kΩ and lists ED, not EA, for its packaging. Both independently reject the proposed code. A custom product would require separate manufacturer documentation.

KOA [RN73R](https://www.koaspeer.com/pdfs/RN73R.pdf) expressly supports 1E/0402, E192 values, 47 Ω–300 kΩ at ±0.1% and ±25 ppm/K. Its order table, [TP package mapping](https://www.koaspeer.com/pdfs/Appendix_A.pdf) and [E192 value table](https://www.koaspeer.com/pdfs/Appendix_D.pdf) jointly support **RN73R1ETTP1563B25**: tin termination, 2 mm-pitch paper tape, 156 kΩ, ±0.1%, ±25 ppm/K. This is manufacturer catalog-combination support, not a claim of exact-SKU inventory, production allocation, or delivery.

The separately checked YAGEO RT family is not the chosen fallback: 156 is an E192 value, which its current [RT sheet](https://yageogroup.com/content/datasheet/asset/file/pyu-rt_1-to-0-01_rohs_l) makes available on request. No exact RT0402BRD07156KL manufacturer product confirmation was obtained.

## Source binding and stress arithmetic

Read-only checks bind the existing C trial board SHA `2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca` and its source `aead2fb0c61ee3cb565f03e3a271f213911767c37f47e86d0adae87735428b3f`. Exact netlist SHA is `e8c372078de57478f807872d71fc5b43f878d751c924e4dd1d96157a7763e77b`. R120=590 kΩ, R121=156 kΩ, both ±0.1%; R121.1/R120.2/U8.2 are the OVLO node, R121.2 is GND. R120's exact MPN and tempco remain unspecified.

There is **no accepted maximum input-fault/transient contract**. The following are examples at VBUS_FUSED, not approved operating limits. Using both resistor tolerances and the [TPS25947 Rev C](https://www.ti.com/lit/ds/symlink/tps25947.pdf) pin leakage limit of ±0.1 µA within its stated 0.5–1.5 V OVLO range:

| Input example | Nominal R121 voltage | Corner R121 voltage range | Maximum R121 power |
|---|---:|---:|---:|
| 5 V | 1.045576 V | 1.031593–1.059576 V | 7.189616 µW |
| 5.25 V | 1.097855 V | 1.083789–1.111938 V | 7.917759 µW |
| 5.5 V | 1.150134 V | 1.135985–1.164299 V | 8.681017 µW |

Standard RN73R1E rating is 63 mW at 85°C ambient, with its 90°C terminal rating and derating requirements also applicable. Working voltage is min(sqrt(P×R), 50 V), hence 50 V here. At the 5.5 V example the voltage ratio to that ceiling is 42.94 and power is 0.01378% of 63 mW. The ambient curve alone gives 27 mW at 125°C, still 3110 times the example dissipation; **this is not a measurement or guarantee of terminal/film temperature**.

A separate 23 V ideal-divider diagnostic gives 4.802–4.817 V and at most 148.608 µW across R121. That node is outside the IC's recommended OVLO range, so the leakage bound was not extended to it. This is only resistor arithmetic, not an allowed operating point, transient/clamp model, or survival result. A regulator's input rating cannot establish a whole-board input contract.

The nominal divider ratio and static threshold are unchanged: 0.2091153 and 5.738462 V for a 1.2 V threshold. The earlier threshold/reference/resistor/leakage-only range remains 5.589286–5.916768 V. It excludes drift, thermal tracking, dynamic noise and layout. `calculate.py` reproduces these results without simulation software.

## Geometry starting point, not assembly approval

Official [KOA Appendix B](https://www.koaspeer.com/pdfs/Appendix_B.pdf), RN73 1E reflow row:
- Pads: 0.40 mm long × 0.30 mm wide; 0.50 mm inner gap, 0.90 mm center spacing, 1.30 mm outside span.
- Component dimensions: L=0.95–1.10 mm, W=0.45–0.55 mm, height=0.30–0.40 mm.
- Top terminations: 0.15–0.35 mm; bottom terminations: 0.15–0.30 mm.

For a vertical placement, this recommended copper occupies 0.30 × 1.30 mm versus the C trial's existing 1.00 × 2.50 mm R121 pad bounding box. If the same existing 0.25 mm per-side ordinary courtyard rule is applied to the union of maximum body and pads, a **derived screening** courtyard would be 1.05 × 1.80 mm. KOA does not specify or approve that courtyard. These dimensions offer room to investigate the conflict; they do not prove clearance at any pose.

A new actual screen must retain ordinary pad/via spacing, maximum terminal and placement envelopes, solder/paste/mask/process margins, all required old support/contact dispositions, rooted returns and exact reference/fill gates. Narrower manufacturer pads cannot be substituted merely to pass a nominal courtyard check. The manufacturer states optimal lands depend on soldering conditions. No vias, traces or pads have been moved here.

## Precision and reliability differences

This is the same nominal value, initial tolerance and TCR class, **not an established stability-equivalent substitution**. The independent source review preserves the exact test conditions:

- RN73R standard 1000-hour endurance allows ±(0.1%R+0.05 Ω) at 85°C; TNPW0603 general-mode allowance is ±(0.05%R+0.01 Ω) at 70°C. The tests differ; do not interpret this as measured comparative drift at the actual low dissipation. No KOA equivalent of the Vishay 8000/225000-hour promises was established.
- RN73R moisture/high-temperature allowances carry a resistance-dependent caveat requiring manufacturer details. Its stated moisture limit is 0.25% plus the fixed term, versus the Vishay humidity test's 0.1% plus its fixed term, at different biases. Do not claim the generic KOA bound is specifically confirmed at 156 kΩ.
- No guaranteed numerical DC voltage coefficient was found in either reviewed sheet. It is not zero by assumption. Small-pad contamination leakage, humidity, thermal gradients and assembly-induced drift remain relevant to this 123.378 kΩ Thevenin-resistance node.
- R121-only ±25 ppm/K over 25→125°C permits up to 0.25% resistance movement and about −0.1972%/+0.1982% threshold movement, holding everything else fixed. R120's unknown TCR prevents a complete tracking bound. Matching the stated TCR class does not make the two discrete resistors track.
- KOA's 5-second overload test is limited to min(2.5×rated voltage,100 V) in standard mode and permits drift; it is not a repetitive-pulse or ESD qualification. No applicable pulse-energy guarantee was established. Use the standard 63 mW mode here, not the 100 mW power-mode headline to imply greater precision.
- Manufacturer handling precautions include ESD sensitivity and ionic-contamination concerns. A manufacturing process review remains necessary.

## Disposition

Eligible **only for an isolated read-only placement/land study**, followed by an explicitly authorized unselected construction if that study satisfies the unchanged gates. Catalog support and low static dissipation are favorable. Stability budget, exact-value moisture caveat, thermal tracking, guaranteed voltage coefficient if required, and actual assembly geometry remain open. No actual startup, pulse, EMC, production, or hardware qualification follows from this result. Existing passive models do not predict changed parasitics merely because the package is smaller.

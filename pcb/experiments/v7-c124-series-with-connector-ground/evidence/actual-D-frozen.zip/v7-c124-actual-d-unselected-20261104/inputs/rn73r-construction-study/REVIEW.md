# RN73R R121 / C124 local successor: analytical pass

**Constructor-ready for a separate UNSELECTED experiment only.** Actual saved candidate validation and independent review are still required. The governing file is CONSTRUCTION_INPUT_CONTRACT.json; earlier alternatives and failed intermediate checks remain preserved.

## Exact source and scope

Analysis uses immutable actual C board2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca. Construction must start from selected commit094851aa91eb49e40182c9a88657a8ed6e6dcba8 / boardc77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a, carry only the separately bound C circuit/companion changes, then this successor. Raw comparison proves c770 differs fromaead solely by the two declared remote GND-track retirements; all other UUID objects and non-UUID fields are exact. Neither removed track is in the local material inventory. Their deletion is explicitly retained in the analytical graph patch and future construction instructions.

All57 actual-C project files match its sealed filled-tree manifest. The current selected54-file map is pinned too. No source CAD, project, BOM, firmware, fill, rule or sealed plan was edited.

## Parts and geometry

- R121 stays at(13.68,18.65), B side, custom vertical orientation0. Proposed **KOA RN73R1ETTP1563B25**,156kΩ±0.1%,25ppm/K. Pad1/OVLO is(13.68,19.10), pad2/GND(13.68,18.20), each0.30×0.40 mm, pitch0.90. Preserve footprint/pad UUIDs. Add a separate RN73R project module and matching unselected schematic/BOM/PCB fields; do not retain the TNPW active identity.
- Official RN73R1E lands are0.40×0.30 with0.50 gap/1.30 span. Body maximum1.10×0.55 mm; top/bottom termination intervals are independently respected. The vertical1.05×1.80 screening courtyard is the max body/land union plus the retained0.25 mm per-side allowance. It is **derived**, not a KOA assembly guarantee. The terminal screen uses the more conservative inner offset0.125 mm, not the earlier RK73/TNPW value.
- C124 moves to(15.185,19.375), same part/lands/pin identity. Its maximum YAGEO occupied box is x14.235…16.135/y18.825…19.925. The future isolated board and module courtyard are explicitly enlarged to1.90×1.10 so the gate is represented in CAD. Preserve the global Reference anchor(8.2,19.8) through the exact local offset(-6.985,0.425).
- R125 remains byte-equivalent to actual C at(15.36,20.48), including its part, lands, pad numbering, reference and courtyard. No UVLO interior, ILM, drill or other footprint moves.

The maximum C124 box clears both the new R121 court and retained R125 court by **0.030 mm**. All original process allowances remain: ±2° rotation, ±0.05 mm XY placement and0.05 mm solder spread per axis. These small positive screens do not qualify the assembly process or final socket/plate/case geometry.

## Explicit routing and support

Retire only actual-C OVLO segments0b861aff… andd0e90a39…. The old x14.25 vertical would leave only0.110 mm to shifted C124.1, so it is explicitly replaced by four ordinary segments with x14.20 in the tight region. The final endpoint segment is0.16 mm; the other three remain0.15.

Add ten exact-ID segments total: four OVLO segments; one0.20 mm R121 GND lead; two0.21 mm source-shaped GND support reinforcements; and the three already reviewed0.16 mm DVDT/OVLO/UVLO boundary stubs. All existing ground bridges and retained source copper remain. The complete integer-nanometre ledger and fixed UUIDs are in the contract.

All eight tested source/interface patches have zero missing area and zero missing contours. This includes the **entire original selected R121 GND patch**, both original C124 GND supports, all four originally deficient signal patches and the current-C lower OVLO boundary. The stronger expanded-old2 nm minus eroded-new2 nm check also passes for all eight.

The first0.15 mm OVLO endpoint proposal had a native8.335e−10 mm²/seven-contour deficit; it is preserved and rejected. The0.16 revision removed it. The next stronger guard exposed coincident-edge ground supports; the final two0.21 mm reinforcements resolve those explicitly. No tiny-area tolerance, endpoint exemption or BUCK precision criterion is used.

## Measurements and topology

Final minima: new foreign copper0.160000 mm; terminal-to-foreign0.157494 mm (unchanged R125 limit); changed-pad to any-net via outer copper0.266575 mm; new copper to actual hole0.163954 mm. Both same-net and foreign via spacing are checked against0.20 mm, separately from drill clearance. Every new non-GND full projection plus an outward2 nm guard is contained in both source inner physical planes. All new GND objects also have zero measured full-projection deficit. No nearby outer B.Cu foreign fill or rule area was omitted from the final supplement.

The analytical graph patch reconstructs the actual-C corrected material graph, removes the declared objects and two remote selected-source deletions, then inserts the new guarded physical contacts. It preserves all **246 net groups and258 named-pad components** exactly. Explicit local paths reach retained OVLO/GND/CAP conductors; the inherited actual native GND roots bind both ordinary return vias to J1.A1. This is a **patched analytical model**, not a fresh native export of a constructed candidate. Four disconnection mutations and a forged cross-net edge are rejected. Removing the short elbow is an explicit topology-positive control because neighboring copper caps still overlap; it would nonetheless violate the future exact geometry ledger. Diagnostic count-label/control-assumption mistakes are preserved separately, with the final labels corrected rather than claiming the old245 count.

Ten new centerline segments total4.4744488439 mm; two removed local segments total1.87 mm. The new R121-to-retained-OVLO path is1.9475280359 mm. Some support copper overlaps existing source copper. These are geometry lengths, not loop impedance, noise pickup or stability results.

## Required actual work and limits

Construction must independently check all raw/companion/component deltas, ordinary masks/paste/silk, normal native fill, strict global/old-reference/support preservation, all actual drills, correctedR2 full-board contacts/roots/partitions, DRC/parity/ERC and exact12-open endpoint components. The candidate must remain unselected pending actual evidence and independent review.

KOA catalog support is not a claim of TNPW-equivalent endurance/humidity drift, pulse performance or stock. Use the separately reviewed RN73R budget. R120 MPN/TCR/thermal tracking remain unresolved. No selected BOM adoption, procurement, active SPICE, startup, hardware stability or manufacturing qualification is implied.

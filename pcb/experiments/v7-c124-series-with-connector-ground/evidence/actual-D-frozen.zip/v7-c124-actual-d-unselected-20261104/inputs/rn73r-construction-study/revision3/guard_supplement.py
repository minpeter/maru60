from pathlib import Path
import os,sys,json,hashlib
sys.dont_write_bytecode=True
D=Path('/tmp/v7-r121-rn73r-local-study/revision3');BP=Path('/tmp/v7-c124-c-actual/filled/pcb/maru60.kicad_pcb');J=Path('/tmp/v7-c124-c-actual/qa/actual-local-material.json');SJ=Path('/tmp/v7-c124-c-actual/qa/source-local-material.json');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();S='2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca';assert sha(BP)==S
for k in['CONFIG_HOME','CACHE_HOME','DATA_HOME','STATE_HOME','RUNTIME_DIR']:
 q=D/'guard-xdg'/k;q.mkdir(parents=True,exist_ok=True);q.chmod(0o700);os.environ['XDG_'+k]=str(q)
import pcbnew as p
j=json.loads(J.read_text());s=json.loads((D/'SCREEN.json').read_text());b=p.LoadBoard(str(BP));assert j['sha256']==S==s['source_sha256']
def poly(sh,out=False):
 q=p.SHAPE_POLY_SET();sh.TransformToPolygon(q,1,p.ERROR_OUTSIDE if out else p.ERROR_INSIDE);q.Simplify();return q
def rings(rows):
 q=p.SHAPE_POLY_SET()
 for r in rows:
  c=p.SHAPE_LINE_CHAIN()
  for x,y in r['outer']:c.Append(p.VECTOR2I(x,y))
  c.SetClosed(True);q.AddOutline(c)
  for h in r['holes']:
   c=p.SHAPE_LINE_CHAIN()
   for x,y in h:c.Append(p.VECTOR2I(x,y))
   c.SetClosed(True);q.AddHole(c,q.OutlineCount()-1)
 return q
v=lambda a:p.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6));holes=[rings(h['polygon'])for h in j['all_physical_holes']];planes={k:rings(x)for k,x in j['inner_planes'].items()};new=[]
for q in s['pads']+s['tracks']:
 if 'at'in q:
  x,y=q['at'];w,h=q['size'];sh=p.SHAPE_RECT(round((x-w/2)*1e6),round((y-h/2)*1e6),round(w*1e6),round(h*1e6))
 else:sh=p.SHAPE_SEGMENT(v(q['start']),v(q['end']),round(q['width_mm']*1e6))
 mm=poly(sh)
 for h in holes:
  if mm.BBox().Intersects(h.BBox()):mm.BooleanSubtract(h)
 new.append((q,sh,mm))
zone_inventory=[];zone_checks=[];rule_checks=[];ref=[]
for z in b.Zones():
 zone_inventory.append({'uuid':z.m_Uuid.AsString(),'net':z.GetNetname(),'rule_area':z.GetIsRuleArea(),'layers':[b.GetLayerName(l)for l in z.GetLayerSet().Seq()]})
 if z.IsOnLayer(p.B_Cu):
  if z.GetIsRuleArea():
   zz=z.Outline();rule_checks.append({'uuid':z.m_Uuid.AsString(),'touching_new':[q['name']for q,sh,m in new if sh.GetClearance(zz)==0]})
  else:
   zz=z.GetFilledPolysList(p.B_Cu)
   if zz.OutlineCount():
    for q,sh,m in new:
     if z.GetNetname()!=q['net']:zone_checks.append({'new':q['name'],'zone':z.m_Uuid.AsString(),'net':z.GetNetname(),'gap_mm':sh.GetClearance(zz)/1e6})
for q,sh,m in new:
 if q['net']=='GND':continue
 for lay,z in planes.items():
  a=poly(sh,True);a.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);a.BooleanSubtract(z);ref.append({'new':q['name'],'layer':lay,'outward2nm_deficit_mm2':a.Area()/1e12,'contours':a.OutlineCount()})
# Robust old-support test: outside-old/inside-new exports are unavailable for full old pad here;
# source-bound1nm inside material patch expanded2nm vs new material eroded2nm is a deliberately stronger local diagnostic.
old=json.loads(SJ.read_text());OM={n['uuid']:rings(n['metal_B'])for n in old['nodes']};M={n['uuid']:rings(n['metal_B'])for n in j['nodes']};N={n['uuid']:n for n in j['nodes']};changed={q['uuid']for q in s['pads']};allM={u:(N[u]['net'],m)for u,m in M.items()if u not in s['retire_relative_to_C']and u not in changed};allM.update({q['name']:(q['net'],m)for q,sh,m in new});support=[]
for r in s['source_support']:
 src=OM if r['source']=='original'else M;oldp=p.SHAPE_POLY_SET();oldp.BooleanIntersection(src[r['old']],src[r['retained_target']]);oldp.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);newp=p.SHAPE_POLY_SET()
 for u,(net,m)in allM.items():
  if net==r['net']and u!=r['retained_target']:newp.BooleanAdd(m)
 newp.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);oldp.BooleanSubtract(newp);support.append({'old':r['old'],'target':r['retained_target'],'expanded_old_minus_eroded_replacement_mm2':oldp.Area()/1e12,'contours':oldp.OutlineCount()})
R={'source_sha256':S,'screen_sha256':sha(D/'SCREEN.json'),'script_sha256':sha(__file__),'board_loads':1,'no_save_fill_setters':True,'zone_inventory':zone_inventory,'foreign_B_zone_checks':zone_checks,'rule_area_checks':rule_checks,'outward2nm_nonGND_reference':ref,'stronger_support_diagnostic':support,'source_unchanged':sha(BP)==S};(D/'GUARDS.json').write_text(json.dumps(R,indent=2)+'\n');print('ZONE MIN',sorted(zone_checks,key=lambda x:x['gap_mm'])[:3]);print('RULE',rule_checks);print('REF FAIL',[r for r in ref if r['contours']or r['outward2nm_deficit_mm2']]);print('SUPPORT FAIL',[r for r in support if r['contours']or r['expanded_old_minus_eroded_replacement_mm2']])

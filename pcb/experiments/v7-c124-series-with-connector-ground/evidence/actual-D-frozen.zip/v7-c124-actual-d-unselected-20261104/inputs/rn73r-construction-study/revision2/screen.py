from pathlib import Path
import sys,os,json,hashlib,math,time
sys.dont_write_bytecode=True
D=Path('/tmp/v7-r121-rn73r-local-study/revision2');BP=Path('/tmp/v7-c124-c-actual/filled/pcb/maru60.kicad_pcb');S='2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(BP)==S
for k in ['CONFIG_HOME','CACHE_HOME','DATA_HOME','STATE_HOME','RUNTIME_DIR']:
 q=D/'xdg'/k;q.mkdir(parents=True,exist_ok=True);q.chmod(0o700);os.environ['XDG_'+k]=str(q)
import pcbnew as p
assert p.Version()=='9.0.2'and p.GetBuildVersion()=='9.0.2+dfsg-1';b=p.LoadBoard(str(BP));F={f.GetReference():f for f in b.GetFootprints()};items=list(b.GetTracks())+[q for f in b.GetFootprints()for q in f.Pads()];uid=lambda q:q.m_Uuid.AsString();idx={uid(q):q for q in items}
J=Path('/tmp/v7-c124-c-actual/qa/actual-local-material.json');SJ=Path('/tmp/v7-c124-c-actual/qa/source-local-material.json');data=json.loads(J.read_text());olddata=json.loads(SJ.read_text());assert data['sha256']==S and olddata['sha256']=='aead2fb0c61ee3cb565f03e3a271f213911767c37f47e86d0adae87735428b3f';nodes={n['uuid']:n for n in data['nodes']};oldnodes={n['uuid']:n for n in olddata['nodes']}
retire=['0b861aff-a06a-5fa5-898f-e20e602a950a','d0e90a39-e58b-5cb7-8db8-b7abb248673b'];changedpads={uid(q)for ref in ['C124','R121']for q in F[ref].Pads()}
def rect(bb):
 x0,y0,x1,y1=[round(x*1e6)for x in bb];s=p.SHAPE_RECT(x0,y0,x1-x0,y1-y0);bb=s.BBox();assert(bb.GetX(),bb.GetY(),bb.GetRight(),bb.GetBottom())==(x0,y0,x1,y1);return s
def poly(s,out=False):
 q=p.SHAPE_POLY_SET();s.TransformToPolygon(q,1,p.ERROR_OUTSIDE if out else p.ERROR_INSIDE);q.Simplify();return q
def rings(rows):
 q=p.SHAPE_POLY_SET()
 for r in rows:
  c=p.SHAPE_LINE_CHAIN()
  for x,y in r['outer']:c.Append(p.VECTOR2I(x,y))
  c.SetClosed(True);q.AddOutline(c)
  for h in r['holes']:
   c=p.SHAPE_LINE_CHAIN()
   for x,y in h:c.Append(p.VECTOR2I(x,y))
   c.SetClosed(True);q.AddHole(c,q.OutlineCount()-1)
 return q
def dump(q):
 def points(c):return [[c.CPoint(i).x,c.CPoint(i).y]for i in range(c.PointCount())]
 return [{'outer':points(q.COutline(i)),'holes':[points(q.CHole(i,h))for h in range(q.HoleCount(i))]}for i in range(q.OutlineCount())]
H=[rings(h['polygon'])for h in data['all_physical_holes']];M={u:rings(n['metal_B'])for u,n in nodes.items()};OM={u:rings(n['metal_B'])for u,n in oldnodes.items()};planes={k:rings(v)for k,v in data['inner_planes'].items()}
def material(s):
 q=poly(s);bb=q.BBox()
 for h in H:
  if bb.Intersects(h.BBox()):q.BooleanSubtract(h)
 return q
def shape(q):return p.SHAPE_CIRCLE(q.GetPosition(),q.GetWidth(p.B_Cu)//2)if isinstance(q,p.PCB_VIA)else q.GetEffectiveShape(p.B_Cu)
def desc(q):
 r={'uuid':uid(q),'net':q.GetNetname(),'kind':q.GetClass()}
 if isinstance(q,p.PAD):r.update(reference=q.GetParentFootprint().GetReference(),number=q.GetNumber())
 return r
win=rect([12,16,22,22]).BBox();existing=[q for q in items if q.IsOnLayer(p.B_Cu)and uid(q)not in changedpads and uid(q)not in retire and win.Intersects(q.GetBoundingBox())];via=[q for q in items if isinstance(q,p.PCB_VIA)and win.Intersects(q.GetBoundingBox())];holes=[q for q in items if isinstance(q,(p.PCB_VIA,p.PAD))and q.HasHole()and win.Intersects(q.GetBoundingBox())]
# Metadata is deliberately proposed, not a BOM or footprint-library edit.
pads=[{'name':'C124.1','uuid':'e99fab95-384f-4c82-aa22-4b94524bb476','net':'USB_DVDT_CAP','at':[14.685,19.375],'size':[.5,.5],'ref':'C124'}, {'name':'C124.2','uuid':'f79380d7-c89c-4396-b53e-4918d8902c13','net':'GND','at':[15.685,19.375],'size':[.5,.5],'ref':'C124'}, {'name':'R121.1','uuid':'2ceda713-c41e-4c74-9962-f6a642f1e236','net':'USB_OVLO','at':[13.68,19.10],'size':[.3,.4],'ref':'R121'}, {'name':'R121.2','uuid':'437d8abf-8e4f-4587-99b7-93c610dd4000','net':'GND','at':[13.68,18.20],'size':[.3,.4],'ref':'R121'}]
tracks=[{'name':'R121_GND_LEG','net':'GND','start':[13.68,18.2],'end':[14,17.675],'width_mm':.2}, {'name':'R121_OLD_GND_SUPPORT','net':'GND','start':[14,17.675],'end':[14.54,17.435],'width_mm':.2}, {'name':'R121_OVLO0','net':'USB_OVLO','start':[13.68,19.1],'end':[14.2,19.45],'width_mm':.15}, {'name':'R121_OVLO1','net':'USB_OVLO','start':[14.2,19.45],'end':[14.2,20.55],'width_mm':.15}, {'name':'R121_OVLO2','net':'USB_OVLO','start':[14.2,20.55],'end':[14.25,20.6],'width_mm':.15}, {'name':'R121_OVLO3','net':'USB_OVLO','start':[14.25,20.6],'end':[14.25,20.75],'width_mm':.16}]
tracks+=json.loads((D/'BOUNDARY_REPAIR_INPUT.json').read_text())['additive_segments'];vec=lambda a:p.VECTOR2I(round(a[0]*1e6),round(a[1]*1e6));new=[]
for q in pads:
 x,y=q['at'];w,h=q['size'];s=rect([x-w/2,y-h/2,x+w/2,y+h/2]);new.append((q,s,material(s)))
for q in tracks:
 s=p.SHAPE_SEGMENT(vec(q['start']),vec(q['end']),round(q['width_mm']*1e6));new.append((q,s,material(s)))
def term(cx,cy,ang,lo,hi,w,sign):
 pts=[]
 for x in[sign*lo,sign*hi]:
  for y in[-w,w]:
   for a in[ang-2,ang,ang+2]:
    a=math.radians(a);pts.append((math.cos(a)*x-math.sin(a)*y,math.sin(a)*x+math.cos(a)*y))
 bb=[math.floor((cx+min(x for x,y in pts)-.1)*1e6)/1e6,math.floor((cy+min(y for x,y in pts)-.1)*1e6)/1e6,math.ceil((cx+max(x for x,y in pts)+.1)*1e6)/1e6,math.ceil((cy+max(y for x,y in pts)+.1)*1e6)/1e6];return rect(bb),bb
terms=[]
for ref,cx,cy,ang,lo,hi,w in [('C124',15.185,19.375,0,.125,.525,.275),('R121',13.68,18.65,90,.125,.55,.275),('R125',15.36,20.48,0,.175,.55,.275)]:
 for sign in[-1,1]:
  num=('1'if sign<0 else'2')if ref=='C124'else('1'if sign>0 else'2');net=next(q.GetNetname()for q in F[ref].Pads()if q.GetNumber()==num);ss,bb=term(cx,cy,ang,lo,hi,w,sign);terms.append((ref,num,net,ss,bb))
rows=[]
for q,s,m in new:
 foreign=[dict(desc(t),gap_mm=s.GetClearance(shape(t))/1e6)for t in existing if t.GetNetname()!=q['net']]
 for q2,s2,m2 in new:
  if q2['net']!=q['net']:foreign.append({'name':q2['name'],'net':q2['net'],'gap_mm':s.GetClearance(s2)/1e6})
 row={'name':q['name'],'net':q['net'],'nearest_foreign':sorted(foreign,key=lambda x:x['gap_mm'])[:4],'nearest_hole':sorted([dict(desc(t),gap_mm=s.GetClearance(t.GetEffectiveHoleShape())/1e6)for t in holes],key=lambda x:x['gap_mm'])[:2],'foreign_terminals':sorted([{'reference':ref,'pad':num,'net':net,'gap_mm':s.GetClearance(ts)/1e6}for ref,num,net,ts,bb in terms if net!=q['net']and ref!=q.get('ref')],key=lambda x:x['gap_mm']),'reference':[]}
 if q in pads:row['all_net_ordinary_via']=sorted([dict(desc(t),gap_mm=s.GetClearance(shape(t))/1e6)for t in via],key=lambda x:x['gap_mm'])[:3]
 for name,z in planes.items():
  miss=p.SHAPE_POLY_SET(m);miss.BooleanSubtract(z);row['reference'].append({'layer':name,'deficit_mm2':miss.Area()/1e12,'contours':miss.OutlineCount(),'nonGND_required':q['net']!='GND'})
 rows.append(row)
termrows=[]
for ref,num,net,ss,bb in terms:
 foreign=[dict(desc(t),gap_mm=ss.GetClearance(shape(t))/1e6)for t in existing if t.GetNetname()!=net and not(isinstance(t,p.PAD)and t.GetParentFootprint().GetReference()==ref)]
 foreign +=[{'name':q['name'],'net':q['net'],'gap_mm':ss.GetClearance(s)/1e6}for q,s,m in new if q['net']!=net and q.get('ref')!=ref]
 other=[{'reference':rr,'pad':nn,'net':nt,'gap_mm':ss.GetClearance(s2)/1e6}for rr,nn,nt,s2,bb2 in terms if nt!=net and rr!=ref]
 termrows.append({'reference':ref,'pad':num,'net':net,'bounds':bb,'nearest_foreign':sorted(foreign,key=lambda x:x['gap_mm'])[:4],'other_terminal_envelopes':sorted(other,key=lambda x:x['gap_mm'])})
# New contacts are physical material (all actual through holes removed), with separate2nm guard.
allmaterial={u:(n['net'],M[u])for u,n in nodes.items()if u not in changedpads and u not in retire};allmaterial.update({q['name']:(q['net'],m)for q,s,m in new});edges=[]
for q,s,m in new:
 for u,(net,mm)in allmaterial.items():
  if u==q['name']or net!=q['net']or not m.BBox().Intersects(mm.BBox()):continue
  z=p.SHAPE_POLY_SET();z.BooleanIntersection(m,mm)
  if z.Area()>0:
   a=p.SHAPE_POLY_SET(m);c=p.SHAPE_POLY_SET(mm);a.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);c.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);a.BooleanIntersection(c);edges.append({'a':q['name'],'b':u,'net':net,'native_area_mm2':z.Area()/1e12,'guard_2nm_mm2':a.Area()/1e12})
# Source patches require a separate replacement side, never the retained target itself.
patches=[('original','437d8abf-8e4f-4587-99b7-93c610dd4000','abcd4fb1-881b-43f9-906e-39d93366692e'),('original','f79380d7-c89c-4396-b53e-4918d8902c13','763086b7-5549-4f5e-bb08-ce25387b3627'),('original','f79380d7-c89c-4396-b53e-4918d8902c13','19181a2b-164e-4055-9004-2860bebe32f4'),('current','d0e90a39-e58b-5cb7-8db8-b7abb248673b','9f71c7e9-1999-5d93-bca7-92de689f89aa')]
for st in tracks:
 if st.get('old'):
  for target in st['targets']:patches.append(('original',st['old'],target))
support=[]
for which,old,target in patches:
 source=OM if which=='original'else M;nsource=oldnodes if which=='original'else nodes;net=nsource[old]['net'];patch=p.SHAPE_POLY_SET();patch.BooleanIntersection(source[old],source[target]);replacement=p.SHAPE_POLY_SET()
 for u,(n,mm)in allmaterial.items():
  if n==net and u!=target:replacement.BooleanAdd(mm)
 missing=p.SHAPE_POLY_SET(patch);missing.BooleanSubtract(replacement);support.append({'source':which,'old':old,'retained_target':target,'net':net,'source_patch_mm2':patch.Area()/1e12,'missing_mm2':missing.Area()/1e12,'missing_contours':missing.OutlineCount(),'missing_polygons':dump(missing)})
# Conservative declared courts/occupied area, avoiding KiCad cached5um inward offset.
courts={'C124_max_occupied':[14.235,18.825,16.135,19.925],'R121_derived_screen':[13.155,17.75,14.205,19.55],'R125_retained':[14.46,19.955,16.26,21.005]};courtrows=[]
for a,bb in courts.items():
 ss=poly(rect(bb));f=[]
 for ref,fp in F.items():
  if ref in['C124','R121','R125']:continue
  fp.BuildCourtyardCaches();cs=fp.GetCourtyard(p.B_CrtYd)
  if cs.OutlineCount()and cs.BBox().Intersects(win):f.append({'reference':ref,'native_cache_gap_mm':ss.GetClearance(cs)/1e6})
 for name,bb2 in courts.items():
  if name!=a:f.append({'reference':name,'exact_declared_bounds_gap_mm':ss.GetClearance(poly(rect(bb2)))/1e6})
 courtrows.append({'name':a,'bounds':bb,'nearest':sorted(f,key=lambda x:x.get('native_cache_gap_mm',x.get('exact_declared_bounds_gap_mm')))[:6]})
R={'status':'analytical full local screen, not a constructed candidate','source_sha256':S,'source_inventory_sha256':sha(J),'original_inventory_sha256':sha(SJ),'board_loads':1,'no_setters_save_fill':True,'retire_relative_to_C':retire,'pads':pads,'tracks':tracks,'checks':rows,'terminal_checks':termrows,'new_physical_contacts':edges,'source_support':support,'court_checks':courtrows,'source_unchanged':sha(BP)==S,'script_sha256':sha(__file__),'failures':{'copper':[r['name']for r in rows if r['nearest_foreign'][0]['gap_mm']<.15],'pad_via':[r['name']for r in rows if r.get('all_net_ordinary_via')and r['all_net_ordinary_via'][0]['gap_mm']<.2],'drills':[r['name']for r in rows if r['nearest_hole'][0]['gap_mm']<.15],'terminal':[(r['reference'],r['pad'],r['nearest_foreign'][0])for r in termrows if r['nearest_foreign'][0]['gap_mm']<.15],'support':[(r['old'],r['retained_target'])for r in support if r['missing_contours']or r['missing_mm2']!=0],'nonGND_reference':[r['name']for r in rows if r['net']!='GND'and any(z['contours']or z['deficit_mm2']!=0 for z in r['reference'])]}}
(D/'SCREEN.json').write_text(json.dumps(R,indent=2)+'\n');print(json.dumps(R['failures'],indent=2));print('min',min(r['nearest_foreign'][0]['gap_mm']for r in rows),min(r['nearest_foreign'][0]['gap_mm']for r in termrows));print('SUPPORT',[(r['old'],r['retained_target'],r['missing_mm2'],r['missing_contours'])for r in support])

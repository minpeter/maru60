import sys
sys.dont_write_bytecode=True
import json, hashlib, re, collections, math
from pathlib import Path
import pcbnew as p
sys.path.insert(0,'/tmp/v7-c124-d-actual/scripts')
from sexpr_spans import children,head,field
R=Path('/tmp/v7-c124-d-actual'); O=Path('/tmp/v7-c124-d-independent-review'); repo=Path('/workspace/scratch/edd9a5be63e7/pcb-v7-recovery-20261104')
S=R/'source/pcb/maru60.kicad_pcb';D=R/'filled/pcb/maru60.kicad_pcb'; selected=repo/'pcb/experiments/v7-gnd-deadbranch-cleanup/candidate/pcb/maru60.kicad_pcb'
H=lambda q:hashlib.sha256(Path(q).read_bytes()).hexdigest(); J=lambda q:json.loads(Path(q).read_text()); W=lambda n,x:(O/n).write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
checks=[]
def check(name,ok,detail=None):
 checks.append({'check':name,'pass':bool(ok),'detail':detail});print(name,bool(ok),flush=True)
source_sha='c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a'; actual_sha='f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b'
check('source_selected_and_snapshot_sha',H(S)==H(selected)==source_sha)
check('actual_sha',H(D)==actual_sha)
C=J(R/'BUILD_CONTRACT.json'); frozen=Path('/tmp/v7-r121-rn73r-local-study/CONSTRUCTION_INPUT_CONTRACT.json'); F=J(frozen)
check('frozen_contract_sha',H(frozen)=='15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd')
check('old_C_unchanged',H('/tmp/v7-c124-c-actual/filled/pcb/maru60.kicad_pcb')=='2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca')
def records(path):
 u={};other=[]
 for _,_,t in children(path.read_text()):
  f=field(t,'uuid')
  if f:u[re.search(r'"([^"]+)"',f).group(1)]=(head(t),t)
  else:other.append(t)
 return u,other
su,so=records(S);du,do=records(D);removed=set(su)-set(du);added=set(du)-set(su);changed={u for u in su.keys()&du.keys() if su[u]!=du[u]}
check('exact_removed_tracks',removed==set(C['retired_track_uuids']),sorted(removed))
check('exact_added_tracks_and_R125',added=={q['uuid']for q in C['added_tracks']}|{F['parts']['R125']['uuid']},sorted(added))
check('exact_changed_footprints',changed==set(C['changed_old_footprint_uuids']),sorted(changed))
check('all_12_raw_zones_exact',len([1 for t,_ in su.values()if t=='zone'])==12 and {u:v for u,v in su.items()if v[0]=='zone'}=={u:v for u,v in du.items()if v[0]=='zone'})
check('non_UUID_settings_only_add_net246',collections.Counter(so)-collections.Counter(do)=={} and list((collections.Counter(do)-collections.Counter(so)).elements())==['(net 246 "USB_DVDT_CAP")'])
sm={str(x.relative_to(S.parent)):H(x)for x in S.parent.rglob('*')if x.is_file()};dm={str(x.relative_to(D.parent)):H(x)for x in D.parent.rglob('*')if x.is_file()};comp={'removed':sorted(sm.keys()-dm.keys()),'added':sorted(dm.keys()-sm.keys()),'changed':sorted(k for k in sm.keys()&dm.keys()if sm[k]!=dm[k])};W('RAW_DELTA.json',{'source_sha':H(S),'candidate_sha':H(D),'companion_delta':comp,'removed':sorted(removed),'added':sorted(added),'changed':sorted(changed),'source_map':sm,'candidate_map':dm})
check('companion_whitelist',not comp['removed'] and set(comp['changed'])=={'maru60.kicad_pcb','Study.kicad_sym','fp-lib-table','protection-input-protection.kicad_sch'} and set(comp['added'])=={'C124_Short_Study.pretty/'+x+'.kicad_mod'for x in ['C_YAGEO_CC0402_050x050_P100_B_Conditional','R_KOA_RK73H1E_0402_Reflow_B','R_KOA_RN73R1E_0402_Reflow_Vertical_B','R_Vishay_TNPW0603_IPC_Vertical_B']} ,comp)
sg=J(R/'qa/source-material-graph-R2.json');dg=J(R/'qa/actual-material-graph.json')
check('fresh_graph_source_binding',sg['board_sha256']==source_sha and dg['board_sha256']==actual_sha and sg['unchanged'] and dg['unchanged'])
changedpads={u for u,q in sg['pad_inventory'].items()if q['ref']in['R121','C124']};affected=removed|changedpads; newpads={u for u,q in dg['pad_inventory'].items()if q['ref']=='R125'};newobjects={q['uuid']for q in C['added_tracks']}|changedpads|newpads
# Rebuild both complete guarded graphs independently; canonical component identity is sorted node membership.
def components(g):
 par={n:n for n in g['material_nodes']}
 def root(n):
  while n!=par[n]:par[n]=par[par[n]];n=par[n]
  return n
 def join(a,b):
  a,b=root(a),root(b)
  if a!=b:par[max(a,b)]=min(a,b)
 for a,b,raw,guard in g['material_edges']:
  assert raw>0 and guard>0;join(a,b)
 for b in g['barrel_joins']:
  for a,z in zip(b['nodes'],b['nodes'][1:]):join(a,z)
 out={n:root(n)for n in par}
 assert out==g['material_roots']
 return out
sr=components(sg);dr=components(dg);check('complete_guarded_graph_DSU_reconstruction',True,{'source_nodes':len(sr),'actual_nodes':len(dr),'source_components':len(set(sr.values())),'actual_components':len(set(dr.values()))})
pi=dict(sg['pad_inventory']);c1=F['parts']['C124']['pad_uuids']['1'];pi[c1]=dict(pi[c1],net='USB_DVDT_CAP');pi.update({u:dg['pad_inventory'][u]for u in newpads});check('exact_intended_pad_inventory',pi==dg['pad_inventory'])
pin=lambda ref,pad:next(u for u,q in dg['pad_inventory'].items()if q['ref']==ref and q['pad']==pad)
r1,r2=pin('R125','1'),pin('R125','2')
expected={n:[sorted([r1 if u==c1 else u for u in group])for group in groups]for n,groups in sg['pad_partitions_by_net'].items()};expected['USB_DVDT_CAP']=[sorted([r2,c1])]
normalize=lambda x:{n:sorted(tuple(sorted(g))for g in groups)for n,groups in x.items()}
check('all_246_expected_pad_partitions',normalize(expected)==normalize(dg['pad_partitions_by_net']),{'nets':len(dg['pad_partitions_by_net']),'named_pad_components':sum(map(len,dg['pad_partitions_by_net'].values())),'pads':len(dg['pad_inventory'])})
stable=set(sg['material_nodes'])&set(dg['material_nodes']);stable={n for n in stable if sg['material_nodes'][n].get('uuid')not in affected}
check('all_retained_material_nodes_exact',all(sg['material_nodes'][n]==dg['material_nodes'][n]for n in stable),len(stable))
check('no_unplanned_material_node_removal',all(v.get('uuid')in affected for n,v in sg['material_nodes'].items()if n not in dg['material_nodes']))
check('no_unplanned_material_node_addition',all(v.get('uuid')in newobjects for n,v in dg['material_nodes'].items()if n not in sg['material_nodes']))
def partitions(roots):
 groups=collections.defaultdict(list)
 for n in stable:groups[roots[n]].append(n)
 return sorted(tuple(sorted(v))for v in groups.values())
check('complete_retained_material_partition_exact',partitions(sr)==partitions(dr))
retainededges=lambda g:sorted(tuple(x)for x in g['material_edges']if x[0]in stable and x[1]in stable)
check('all_retained_guarded_edges_exact',retainededges(sg)==retainededges(dg),len(retainededges(sg)))
check('all_barrel_joins_exact',sg['barrel_joins']==dg['barrel_joins'],len(sg['barrel_joins']))
check('all_51_guard_failures_exact',sg['guard_failing_material_edges']==dg['guard_failing_material_edges'],len(dg['guard_failing_material_edges']))
gnd=[u for u,q in sg['pad_inventory'].items()if q['net']=='GND'];check('all_247_GND_pad_roots_exact',len(gnd)==247 and all(sg['object_material_roots'][u]==dg['object_material_roots'][u]for u in gnd))
witness={f'{r}.{n}':{'uuid':pin(r,n),'net':dg['pad_inventory'][pin(r,n)]['net'],'roots':dg['object_material_roots'][pin(r,n)]}for r,n in [('U8','7'),('R125','1'),('R125','2'),('C124','1'),('C124','2'),('R121','1'),('R121','2')]}
a=witness['U8.7']['roots'];b=witness['R125.2']['roots'];g=witness['C124.2']['roots'];check('exact_series_order_and_no_material_bypass',len(a)==len(b)==len(g)==1 and a==witness['R125.1']['roots'] and b==witness['C124.1']['roots'] and not(set(a)&set(b)or set(b)&set(g)or set(a)&set(g)),witness)
# All native open endpoint relationships against reconstructed physical components, not descriptions/count alone.
sd=J(R/'qa/source-drc.json');dd=J(R/'qa/filled-drc.json')
root_signatures={}
for label,gx,roots in [('source',sg,sr),('actual',dg,dr)]:
 groups=collections.defaultdict(list)
 for n in stable:groups[roots[n]].append(n)
 root_signatures[label]={r:hashlib.sha256('\n'.join(sorted(ns)).encode()).hexdigest()for r,ns in groups.items()}
def opens(d,g,label):
 result=[]
 for row in d['unconnected_items']:
  ep=[]
  for q in row['items']:
   roots=g['object_material_roots'][q['uuid']];assert len(roots)==1
   ep.append(root_signatures[label][roots[0]])
  assert len(ep)==2 and ep[0]!=ep[1]
  result.append(tuple(sorted(ep)))
 return sorted(result)
check('all_12_native_open_component_pairs_exact',len(sd['unconnected_items'])==len(dd['unconnected_items'])==12 and opens(sd,sg,'source')==opens(dd,dg,'actual'))
check('raw_12_open_records_exact',sd['unconnected_items']==dd['unconnected_items'])
check('native_parity_zero',dd['schematic_parity']==[])
check('native_non_open_errors_zero',not[q for q in dd['violations']if q['severity']!='warning'])
canon=lambda q:json.dumps(q,sort_keys=True)
oldwarn={canon(q):q for q in sd['violations']};newwarn={canon(q):q for q in dd['violations']};warn={'source_count':len(oldwarn),'actual_count':len(newwarn),'removed':[oldwarn[k]for k in sorted(oldwarn.keys()-newwarn.keys())],'added':[newwarn[k]for k in sorted(newwarn.keys()-oldwarn.keys())]};W('WARNING_AND_OPEN_REVIEW.json',dict(warn,source_sha=H(S),candidate_sha=H(D),all_12_component_pairs_unchanged=True,raw_12_open_records_exact=True,three_new_native_warnings_remain_unwaived=True))
W('MATERIAL_GRAPH_REVIEW.json',{'source_sha':H(S),'candidate_sha':H(D),'source_graph_sha':H(R/'qa/source-material-graph-R2.json'),'candidate_graph_sha':H(R/'qa/actual-material-graph.json'),'pin_witnesses':witness,'checks':[q for q in checks if q['check'].startswith(('all_','complete_','no_unplanned','exact_intended','exact_series','fresh_graph'))]})
# Independently enumerate EVERY source affected-to-retained material boundary. No source-plan list used to discover them.
sl=J(R/'qa/source-local-material.json');dl=J(R/'qa/actual-local-material.json');cl=J('/tmp/v7-c124-c-actual/qa/actual-local-material.json')
def polys(rows):
 out=p.SHAPE_POLY_SET()
 for row in rows:
  chain=p.SHAPE_LINE_CHAIN()
  for x,y in row['outer']:chain.Append(x,y)
  chain.SetClosed(True);n=out.AddOutline(chain)
  for ring in row['holes']:
   chain=p.SHAPE_LINE_CHAIN()
   for x,y in ring:chain.Append(x,y)
   chain.SetClosed(True);out.AddHole(chain,n)
 return out
smetal={q['uuid']:polys(q['metal_B'])for q in sl['nodes']};dmetal={q['uuid']:polys(q['metal_B'])for q in dl['nodes']};cmetal={q['uuid']:polys(q['metal_B'])for q in cl['nodes']};dn={q['uuid']:q for q in dl['nodes']}
boundaries=[]
for edge in sl['edges']:
 x,y=edge['a'],edge['b']
 if (x in affected)^(y in affected):
  old,target=(x,y)if x in affected else(y,x);boundaries.append(('c770',old,target,edge['net'],smetal))
boundaries.append(('C2c57','d0e90a39-e58b-5cb7-8db8-b7abb248673b','9f71c7e9-1999-5d93-bca7-92de689f89aa','USB_OVLO',cmetal))
proof=[]
for label,old,target,net,m in boundaries:
 patch=p.SHAPE_POLY_SET();patch.BooleanIntersection(m[old],m[target]);assert patch.Area()>0
 repl=p.SHAPE_POLY_SET();newonly=p.SHAPE_POLY_SET()
 for u,q in dmetal.items():
  if u!=target and dn[u]['net']==net:
   repl.BooleanAdd(q)
   if u in newobjects:newonly.BooleanAdd(q)
 nominal=p.SHAPE_POLY_SET(patch);nominal.BooleanSubtract(repl)
 expanded=p.SHAPE_POLY_SET(patch);expanded.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1)
 eroded=p.SHAPE_POLY_SET(repl);eroded.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);expanded.BooleanSubtract(eroded)
 strongest=p.SHAPE_POLY_SET(patch);strongest.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);newonly.Inflate(-2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1);strongest.BooleanSubtract(newonly)
 proof.append({'source':label,'old':old,'retained':target,'net':net,'old_area_mm2':patch.Area()/1e12,'nominal_missing_mm2':nominal.Area()/1e12,'nominal_missing_contours':nominal.OutlineCount(),'strong_missing_mm2':expanded.Area()/1e12,'strong_missing_contours':expanded.OutlineCount(),'added_or_changed_only_strong_missing_mm2':strongest.Area()/1e12,'added_or_changed_only_strong_missing_contours':strongest.OutlineCount()})
check('all_independently_enumerated_external_support_pass',all(not any(x[k]for k in ['nominal_missing_mm2','nominal_missing_contours','strong_missing_mm2','strong_missing_contours'])for x in proof),{'count':len(proof),'original_count':len(proof)-1})
check('strong_support_also_from_added_or_changed_only',all(not(x['added_or_changed_only_strong_missing_mm2']or x['added_or_changed_only_strong_missing_contours'])for x in proof))
check('all_1269_physical_holes_exact',len(sl['all_physical_holes'])==1269 and sl['all_physical_holes']==dl['all_physical_holes'])
check('actual_local_both_physical_inner_planes_exact',sl['inner_planes']==dl['inner_planes'])
W('SOURCE_SUPPORT_REVIEW.json',{'source_sha':H(S),'candidate_sha':H(D),'boundaries':proof,'discovery':'All corrected local-material same-net edges crossing source affected/retained cut; no manually supplied original boundary list. Added current C lower OVLO boundary separately. All physical holes already cut. Retained target excluded from replacement union. 2nm expanded old minus 2nm eroded replacement, area AND contour count checked.'})
# Bounded native read-only shapes, no fresh full-board material export or refill.
b=p.LoadBoard(str(D));items=list(b.GetTracks())+[pad for fp in b.GetFootprints()for pad in fp.Pads()];idx={q.m_Uuid.AsString():q for q in items};planes={l:polys(q)for l,q in dl['inner_planes'].items()};ref=[]
for u in sorted(newobjects):
 item=idx[u]
 if item.GetNetname()=='GND':continue
 outer=p.SHAPE_POLY_SET();item.GetEffectiveShape(p.B_Cu).TransformToPolygon(outer,1,p.ERROR_OUTSIDE);outer.Simplify();outer.Inflate(2,p.CORNER_STRATEGY_ROUND_ALL_CORNERS,1)
 for layer,plane in planes.items():
  delta=p.SHAPE_POLY_SET(outer);delta.BooleanSubtract(plane);ref.append({'uuid':u,'net':item.GetNetname(),'layer':layer,'outside_area_mm2':delta.Area()/1e12,'outside_contours':delta.OutlineCount()})
check('whole_new_nonGND_outward2nm_reference',all(not(q['outside_area_mm2']or q['outside_contours'])for q in ref),len(ref));W('ACTUAL_REFERENCE_REVIEW.json',{'source_sha':H(S),'candidate_sha':H(D),'whole_shape_outward_2nm':ref,'physical_planes_have_all_1269_holes_cut':True,'no_endpoint_exclusion':True})
check('all_input_boards_unchanged_end',H(S)==H(selected)==source_sha and H(D)==actual_sha)
W('CHECKS.json',checks);print('FINISHED',len(checks),'FAILURES',[q['check']for q in checks if not q['pass']],flush=True)

"""Independent, read-only KiCad S-expression/XML binding review. No native jobs."""
import re, json, hashlib, collections, pathlib, math, copy, xml.etree.ElementTree as ET
O=pathlib.Path('/tmp/v7-c124-d-binding-review')
S=pathlib.Path('/workspace/scratch/edd9a5be63e7/pcb-v7-recovery-20261104/pcb/experiments/v7-gnd-deadbranch-cleanup/candidate/pcb')
C=pathlib.Path('/tmp/v7-c124-c-actual/filled/pcb')
D=pathlib.Path('/tmp/v7-c124-d-actual')
K=pathlib.Path('/tmp/v7-r121-rn73r-local-study/CONSTRUCTION_INPUT_CONTRACT.json')
EXPECTED_K='15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd'
EXPECTED_S='c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a'
EXPECTED_C='2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(text):
    stack=[]; root=None
    for m in re.finditer(r'\(|\)|"(?:\\.|[^"\\])*"|[^\s()]+',text):
        t=m.group()
        if t=='(':
            n=[]
            if stack:stack[-1].append(n)
            stack.append(n)
        elif t==')':
            n=stack.pop()
            if not stack:root=n
        else:stack[-1].append(json.loads(t) if t.startswith('"') else t)
    assert not stack and root is not None
    return root

def get(p):return parse(p.read_text())
def many(n,k):return [x for x in n[1:] if isinstance(x,list) and x and x[0]==k]
def one(n,k):return next(iter(many(n,k)),None)
def val(n,k):
    x=one(n,k)
    return x[1:] if x is not None else None

def props(n):return {x[1]:x[2] for x in many(n,'property')}
def prop(n,k):return next((x for x in many(n,'property') if x[1]==k),None)
def norm(n):
    if not isinstance(n,list):return n
    if n and n[0]=='net':return ['net',n[-1]]
    return [norm(x) for x in n]
def near(a,b):return len(a)==len(b) and all(abs(float(x)-float(y))<1e-8 for x,y in zip(a,b))
def floats(x):return [float(t) for t in x]
def fps(n):return {props(x).get('Reference'):x for x in many(n,'footprint')}
def ref_global(fp):
    pos=floats(val(fp,'at')); r=floats(val(prop(fp,'Reference'),'at'))
    a=math.radians(pos[2] if len(pos)>2 else 0)
    return [pos[0]+r[0]*math.cos(a)+r[1]*math.sin(a),pos[1]-r[0]*math.sin(a)+r[1]*math.cos(a)]
def summary(fp):
    return {'footprint':fp[1],'properties':props(fp),'at':val(fp,'at'),'layer':val(fp,'layer'),'uuid':val(fp,'uuid'),'path':val(fp,'path'),'reference_global':ref_global(fp),'pads':[{k:val(p,k) for k in ['at','size','layers','net','uuid']}|{'number':p[1],'type':p[2],'shape':p[3]} for p in many(fp,'pad')],'rectangles':[{'layer':val(r,'layer'),'start':val(r,'start'),'end':val(r,'end'),'uuid':val(r,'uuid')} for r in many(fp,'fp_rect')]}
def filemap(root):return {str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
def delta(a,b):return {'added':sorted(b.keys()-a.keys()),'removed':sorted(a.keys()-b.keys()),'changed':sorted(k for k in a.keys()&b.keys() if a[k]!=b[k])}
def rect_dims(fp,layer):
    r=next(x for x in many(fp,'fp_rect') if val(x,'layer')==[layer]);a,b=map(lambda k:floats(val(r,k)),['start','end'])
    return [abs(b[i]-a[i]) for i in range(2)]
def except_children(n,k):return [x for x in n if not(isinstance(x,list) and x and x[0] in k)]
def tree_changes(a,b,path=()):
    if type(a)!=type(b):return [{'path':list(path),'C':a,'D':b}]
    if isinstance(a,list):
        if len(a)!=len(b):return [{'path':list(path),'C':a,'D':b}]
        out=[]
        for i,(x,y) in enumerate(zip(a,b)):out.extend(tree_changes(x,y,path+(i,)))
        return out
    return [] if a==b else [{'path':list(path),'C':a,'D':b}]

def precheck():
    contract=json.loads(K.read_text()); sf=fps(get(S/'maru60.kicad_pcb'));cf=fps(get(C/'maru60.kicad_pcb'))
    sm,cm=filemap(S),filemap(C)
    checks={'contract_sha':sha(K)==EXPECTED_K,'selected_sha':sha(S/'maru60.kicad_pcb')==EXPECTED_S,'C_sha':sha(C/'maru60.kicad_pcb')==EXPECTED_C}
    report={'status':'D pending; immutable sources and expected binding scope prepared','checks':checks,'source_vs_C_files':delta(sm,cm),'source_vs_C_footprints':delta({r:norm(f) for r,f in sf.items()},{r:norm(f) for r,f in cf.items()}),'C_components':{r:summary(cf[r]) for r in contract['parts']},'expected':contract['parts']}
    (O/'PRECONSTRUCTION.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['C_components','expected']},indent=2))
    return contract,sf,cf,sm,cm

def review():
    k,sf,cf,sm,cm=precheck()
    P=D/'filled/pcb'
    if not (P/'maru60.kicad_pcb').exists():P=D/'prefill/pcb'
    if not (P/'maru60.kicad_pcb').exists():return
    df=fps(get(P/'maru60.kicad_pcb'));dm=filemap(P)
    checks={};actual={};viol=[]
    def check(label,condition):
        checks[label]=bool(condition)
        if not condition:viol.append(label)
    check('source_hash_bound',sha(S/'maru60.kicad_pcb')==EXPECTED_S)
    check('C_hash_bound',sha(C/'maru60.kicad_pcb')==EXPECTED_C)
    check('contract_hash_bound',sha(K)==EXPECTED_K)
    frozen_maps=json.loads(pathlib.Path('/tmp/v7-r121-rn73r-local-study/PROJECT_INPUT_MAPS.json').read_text())
    check('all_selected_files_match_frozen_map',sm==frozen_maps['selected_c770']['files'])
    check('all_C_files_match_frozen_map',cm==frozen_maps['actual_C']['files'])
    fp_delta=delta({r:norm(f) for r,f in cf.items()},{r:norm(f) for r,f in df.items()})
    check('only_R121_C124_footprints_changed_from_C',fp_delta=={'added':[],'removed':[],'changed':['C124','R121']})
    check('R125_entire_structural_footprint_preserved',cf['R125']==df['R125'])
    check('all_other_footprints_exact_structural_from_C',all(cf[r]==df[r] for r in cf if r not in ['R121','C124']))
    refdiff=[]
    for r in cf:
        if not near(ref_global(cf[r]),ref_global(df[r])):refdiff.append(r)
    check('all_global_reference_anchors_preserved',not refdiff)
    check('all_reference_UUID_font_mirror_preserved',all(except_children(prop(cf[r],'Reference'),['at'])==except_children(prop(df[r],'Reference'),['at']) for r in cf))
    sch_C=get(C/'protection-input-protection.kicad_sch');sch_D=get(P/'protection-input-protection.kicad_sch')
    sc={props(x)['Reference']:x for x in many(sch_C,'symbol')};sd={props(x)['Reference']:x for x in many(sch_D,'symbol')}
    schdelta=delta(sc,sd)
    check('schematic_only_R121_instance_changed_from_C',schdelta=={'added':[],'removed':[],'changed':['R121']})
    check('schematic_all_other_objects_exact_from_C',except_children(sch_C,['symbol'])==except_children(sch_D,['symbol']))
    bpath=D/'BOM_PROPOSAL.json';bom=json.loads(bpath.read_text()) if bpath.exists() else None
    if bom is None:viol.append('BOM_PROPOSAL.json pending')
    fp_lib=get(P/'fp-lib-table');libs={val(x,'name')[0]:x for x in many(fp_lib,'lib')}
    check('local_library_resolves_KIPRJMOD',val(libs['C124_Short_Study'],'uri')==['${KIPRJMOD}/C124_Short_Study.pretty'])
    expected_files={'maru60.kicad_pcb','protection-input-protection.kicad_sch','C124_Short_Study.pretty/C_YAGEO_CC0402_050x050_P100_B_Conditional.kicad_mod'}
    dfiles=delta(cm,dm)
    check('only_expected_C_companions_changed',set(dfiles['changed'])==expected_files and not dfiles['removed'] and dfiles['added']==['C124_Short_Study.pretty/R_KOA_RN73R1E_0402_Reflow_Vertical_B.kicad_mod'])
    for r,e in k['parts'].items():
        fp=df[r]; sp=sd[r];libpath=P/(e['footprint'].split(':')[0]+'.pretty')/(e['name']+'.kicad_mod');lib=get(libpath)
        actual[r]={'board':summary(fp),'schematic_properties':props(sp),'module_sha256':sha(libpath),'BOM':bom['parts'].get(r) if bom else None}
        check(r+'.PCB_name',fp[1]==e['footprint']);check(r+'.SCH_name',props(sp)['Footprint']==e['footprint']);check(r+'.module_name',lib[1]==e['name'])
        check(r+'.B_Cu',val(fp,'layer')==val(lib,'layer')==['B.Cu']);check(r+'.pose',near(val(fp,'at'),e['at']))
        check(r+'.root_UUID',val(fp,'uuid')==[e['uuid']]);check(r+'.schematic_UUID',val(sp,'uuid')==[e['sch']]);check(r+'.schematic_path',val(fp,'path')[0].endswith('/'+e['sch']))
        check(r+'.in_bom_on_board_not_dnp',val(sp,'in_bom')==['yes'] and val(sp,'on_board')==['yes'] and val(sp,'dnp')==['no'])
        for pp,field in [('Value','value'),('Manufacturer','maker'),('MPN','mpn'),('Datasheet','datasheet')]:
            for label,obj in [('PCB',fp),('SCH',sp),('module',lib)]:check(r+'.'+label+'.'+pp,props(obj).get(pp)==e[field])
            if bom:check(r+'.BOM.'+field,bom['parts'][r].get(field)==e[field])
        if bom:
            be=bom['parts'][r]
            for fld in ['name','footprint','sch','uuid']:check(r+'.BOM.'+fld,be.get(fld)==e[fld])
            for fld in ['at','body','court','refat']:check(r+'.BOM.'+fld,near(be.get(fld,[]),e[fld]))
        check(r+'.body',near(rect_dims(fp,'B.Fab'),e['body']) and near(rect_dims(lib,'B.Fab'),e['body']))
        check(r+'.courtyard',near(rect_dims(fp,'B.CrtYd'),e['court']) and near(rect_dims(lib,'B.CrtYd'),e['court']))
        check(r+'.global_reference',near(ref_global(fp),e['refat']))
        check(r+'.no_3d_model_invented',many(fp,'model')==many(cf[r],'model'))
        cp={p[1]:p for p in many(cf[r],'pad')};dp={p[1]:p for p in many(fp,'pad')};lp={p[1]:p for p in many(lib,'pad')}
        check(r+'.pad_count',len(dp)==len(lp)==2)
        check(r+'.graphics_UUIDs_preserved',[val(x,'uuid') for x in many(fp,'fp_rect')]==[val(x,'uuid') for x in many(cf[r],'fp_rect')])
        for pn,x,y,w,h,net in e['pads']:
            p=dp[pn];l=lp[pn]
            for label,pad in [('PCB',p),('module',l)]:
                check(r+'.'+label+'.pad'+pn+'.geometry',pad[2:4]==['smd','rect'] and near(val(pad,'at'),[x,y]) and near(val(pad,'size'),[w,h]))
                check(r+'.'+label+'.pad'+pn+'.ordinary_aperture',set(val(pad,'layers'))=={'B.Cu','B.Mask','B.Paste'} and not any(one(pad,z) for z in ['solder_mask_margin','solder_paste_margin','solder_paste_margin_ratio','clearance']))
            check(r+'.pad'+pn+'.net',val(p,'net')[-1]==net)
            check(r+'.pad'+pn+'.UUID_preserved',val(p,'uuid')==val(cp[pn],'uuid'))
            if pn in e['pad_uuids']:check(r+'.pad'+pn+'.UUID_contract',val(p,'uuid')==[e['pad_uuids'][pn]])
            if bom:
                bp=next(z for z in bom['parts'][r]['pads'] if z[0]==pn)
                check(r+'.BOM.pad'+pn,near(bp[1:5],[x,y,w,h]) and bp[5]==net)
        check(r+'.no_fp_mask_paste_override',not any(one(fp,z) for z in ['solder_mask_margin','solder_paste_margin','solder_paste_margin_ratio']))
    # Independently reconstruct the exact allowed footprint/module field edits from frozen C.
    def replace_floats(node,key,values):
        c=one(node,key);c[1:1+len(values)]=[format(float(x),'.12g') for x in values]
    def geometry(n,e):
        for layer,dimensions in [('B.Fab',e['body']),('B.CrtYd',e['court'])]:
            rr=next(x for x in many(n,'fp_rect') if val(x,'layer')==[layer]);w,h=dimensions
            replace_floats(rr,'start',[-w/2,-h/2]);replace_floats(rr,'end',[w/2,h/2])
        for pn,x,y,w,h,net in e['pads']:
            pad=next(z for z in many(n,'pad') if z[1]==pn)
            replace_floats(pad,'at',[x,y]);replace_floats(pad,'size',[w,h])
    def update_R121(n,e,isboard):
        n[1]=e['footprint'] if isboard else e['name']
        for f,b in [('Manufacturer','maker'),('MPN','mpn'),('Datasheet','datasheet')]:prop(n,f)[2]=e[b]
        geometry(n,e)
    expR=copy.deepcopy(cf['R121']);update_R121(expR,k['parts']['R121'],True)
    expC=copy.deepcopy(cf['C124']);replace_floats(expC,'at',k['parts']['C124']['at'])
    replace_floats(prop(expC,'Reference'),'at',k['parts']['C124']['reference_local_at']);geometry(expC,k['parts']['C124'])
    check('R121.exact_contract_field_transform_from_C',expR==df['R121'])
    check('C124.exact_contract_field_transform_from_C',expC==df['C124'])
    oldmod='C124_Short_Study.pretty/R_Vishay_TNPW0603_IPC_Vertical_B.kicad_mod'
    newmod='C124_Short_Study.pretty/R_KOA_RN73R1E_0402_Reflow_Vertical_B.kicad_mod'
    exprm=get(C/oldmod);update_R121(exprm,k['parts']['R121'],False)
    check('R121.module_exact_identity_geometry_transform_from_historical_C',exprm==get(P/newmod))
    cmp='C124_Short_Study.pretty/C_YAGEO_CC0402_050x050_P100_B_Conditional.kicad_mod'
    expcm=get(C/cmp);geometry(expcm,k['parts']['C124'])
    check('C124.module_exact_courtyard_only_transform_from_C',expcm==get(P/cmp))
    def raw_footprints(path):
        text=path.read_text();depth=0;quoted=False;escape=False;start=None;out={}
        for i,char in enumerate(text):
            if quoted:
                if escape:escape=False
                elif char=='\\':escape=True
                elif char=='"':quoted=False
                continue
            if char=='"':quoted=True
            elif char=='(':
                depth+=1
                if depth==2:start=i
            elif char==')':
                if depth==2:
                    x=text[start:i+1]
                    if x.startswith('(footprint '):out[props(parse(x))['Reference']]=x
                depth-=1
        return out
    cr,dr=raw_footprints(C/'maru60.kicad_pcb'),raw_footprints(P/'maru60.kicad_pcb')
    check('R125.entire_raw_footprint_byte_preserved',cr['R125']==dr['R125'])
    check('all_other_raw_footprints_byte_preserved',all(cr[r]==dr[r] for r in cr if r not in ['C124','R121']))
    raw_deltas={r:tree_changes(cf[r],df[r]) for r in ['R121','C124']}
    raw_hashes={'R125_C':hashlib.sha256(cr['R125'].encode()).hexdigest(),'R125_D':hashlib.sha256(dr['R125'].encode()).hexdigest()}

    # Specific field-only schematic constraint: existing R121 pin definitions, instance, value and status remain exact.
    rcs,rds=sc['R121'],sd['R121']
    check('R121.schematic_nonproperty_fields_preserved',except_children(rcs,['property'])==except_children(rds,['property']))
    prop_changes={p[1]:tree_changes(p,prop(rds,p[1])) for p in many(rcs,'property') if p!=prop(rds,p[1])}
    check('R121.schematic_properties_only_identity_change',set(prop_changes)=={'Footprint','Datasheet','Manufacturer','MPN'} and all(all(z['path']==[2] for z in changes) for changes in prop_changes.values()))
    check('C124.module_only_courtyard_changed',except_children(get(C/'C124_Short_Study.pretty/C_YAGEO_CC0402_050x050_P100_B_Conditional.kicad_mod'),['fp_rect'])==except_children(get(P/'C124_Short_Study.pretty/C_YAGEO_CC0402_050x050_P100_B_Conditional.kicad_mod'),['fp_rect']))
    check('old_TNPW_module_exact_unused',dm.get('C124_Short_Study.pretty/R_Vishay_TNPW0603_IPC_Vertical_B.kicad_mod')==cm.get('C124_Short_Study.pretty/R_Vishay_TNPW0603_IPC_Vertical_B.kicad_mod') and all('TNPW' not in f[1] for f in df.values()) and 'TNPW' not in json.dumps(sd))
    xmlpath=D/'qa/netlist.xml';xr={}
    if xmlpath.exists():
        xml=ET.parse(xmlpath).getroot(); xc={x.get('ref'):x for x in xml.findall('components/comp')};nets={x.get('name'):[(z.get('ref'),z.get('pin')) for z in x.findall('node')] for x in xml.findall('nets/net')};pinnet=collections.defaultdict(set)
        for nn,nodes in nets.items():
            for pp in nodes:pinnet[pp].add(nn)
        pcbpn=collections.defaultdict(set)
        for r,fp in df.items():
            for p in many(fp,'pad'):
                n=val(p,'net')
                if p[1] and n:pcbpn[(r,p[1])].add(n[-1])
        mism=[{'pin':pp,'PCB':sorted(pcbpn[pp]),'XML':sorted(pinnet[pp])} for pp in pcbpn.keys()&pinnet.keys() if pcbpn[pp]!=pinnet[pp]]
        xr={'sha256':sha(xmlpath),'shared_named_pin_count':len(pcbpn.keys()&pinnet.keys()),'PCB_only':sorted(pcbpn.keys()-pinnet.keys()),'XML_only':sorted(pinnet.keys()-pcbpn.keys()),'mismatches':mism}
        check('all_PCB_XML_named_pins_match',not mism and pcbpn.keys()==pinnet.keys())
        check('exact_DVDT_membership',set(nets['USB_DVDT'])=={('U8','7'),('R125','1')})
        check('exact_DVDT_CAP_membership',set(nets['USB_DVDT_CAP'])=={('R125','2'),('C124','1')})
        Cxml=ET.parse('/tmp/v7-c124-c-actual/qa/netlist.xml').getroot();cnets={x.get('name'):sorted((z.get('ref'),z.get('pin')) for z in x.findall('node')) for x in Cxml.findall('nets/net')}
        check('all_XML_nets_exact_C',cnets=={n:sorted(p) for n,p in nets.items()})
        ccomps={x.get('ref'):x for x in Cxml.findall('components/comp')}
        for r,e in k['parts'].items():
            x=xc[r];fields={f.get('name'):f.text for f in x.findall('fields/field')};xp={f.get('name'):f.get('value') for f in x.findall('property')}
            for field,bfield in [('value','value'),('footprint','footprint'),('datasheet','datasheet'),('tstamps','sch')]:check(r+'.XML.'+field,x.findtext(field)==e[bfield])
            for field,bfield in [('Manufacturer','maker'),('MPN','mpn')]:check(r+'.XML.'+field,fields.get(field)==xp.get(field)==e[bfield])
            for pn,*_,net in e['pads']:check(r+'.XML.pin'+pn,pinnet[(r,pn)]=={net})
        check('all_non_R121_XML_components_exact_C',xc.keys()==ccomps.keys() and all(ET.tostring(xc[r])==ET.tostring(ccomps[r]) for r in xc if r!='R121'))
    else:xr={'status':'native XML export pending'}
    pre=D/'prefill/pcb'
    if P!=pre and (pre/'maru60.kicad_pcb').exists():
        ppf=fps(get(pre/'maru60.kicad_pcb'));check('refill_footprints_unchanged',df==ppf)
        pm=filemap(pre);pd=delta(pm,dm);check('refill_companions_unchanged',pd=={'added':[],'removed':[],'changed':['maru60.kicad_pcb']})
    native={}
    for name,key in [('erc.json','ERC'),('filled-drc.json','DRC')]:
        path=D/'qa'/name
        if path.exists():
            data=json.loads(path.read_text());native[key]={'path':str(path),'sha256':sha(path),'consumed_parent_output_not_reexecuted':True}
            if key=='ERC':native[key]['violations']=sum(len(x.get('violations',[])) for x in data.get('sheets',[]));check('parent_native_ERC_zero_violations',native[key]['violations']==0)
            else:native[key].update({'schematic_parity_count':len(data['schematic_parity']),'unconnected_count':len(data['unconnected_items']),'violations_by_type':dict(collections.Counter(x['type'] for x in data['violations']))});check('parent_native_schematic_parity_zero',not data['schematic_parity'])
    report={'status':'PASS binding scope' if not viol and xmlpath.exists() and P!=pre else 'CHECK_FAILURE_OR_PENDING','scope':'component/schematic/BOM/local-module/static XML logical binding only; no full-board native job launched','board_path':str(P/'maru60.kicad_pcb'),'sha256':{'selected':sha(S/'maru60.kicad_pcb'),'C':sha(C/'maru60.kicad_pcb'),'D':sha(P/'maru60.kicad_pcb'),'contract':sha(K),'BOM':sha(bpath) if bom else None},'checks':checks,'violations':viol,'footprint_delta_C_to_D':fp_delta,'file_delta_C_to_D':dfiles,'reference_anchor_changes':refdiff,'schematic_delta_C_to_D':schdelta,'R121_schematic_property_diffs':prop_changes,'XML':xr,'native_outputs':native,'exact_footprint_diffs':raw_deltas,'raw_footprint_hashes':raw_hashes,'footprint_count':len(df),'actual':actual,'qualification':{'selection':False,'procurement':False,'assembly':False,'manufacturer_process':False,'analog_startup':False,'active_SPICE':False,'hardware_stability':False,'RN73R_equivalent_to_TNPW_drift':False}}
    (O/'COMPONENT_BINDING_REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['actual','checks','R121_schematic_property_diffs']},indent=2))
if __name__=='__main__':review()

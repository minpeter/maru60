# Independent actual-D component binding review

Verdict: **PASS for component identity, schematic/BOM/local-module/PCB/XML agreement and exact declared component changes.** The 223 static checks pass. This is not selected adoption, assembly approval, physical-connectivity certification, or analog qualification.

## Bound artifacts

- Current selected board: `c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a`
- Immutable C board: `2c57bb80b6e985fd63b6414cfea52c9ce6f9b631928a3d4476d175d05c1f38ca`
- Frozen construction contract: `15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd`
- D filled board: `f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b`
- D native XML netlist: `05b0032974c95e00e7b563cd8ffadadbb6d72d51e266706f813609c08ca01b6d`
- D BOM proposal: `2afe6c449e09d147e40c9ce727b566e1f6321efc1c08cb907ab82b9b76aa7b3f`

All selected and C project files still match their complete frozen input maps. The reviewer read candidate/source files without editing them and wrote only this review directory. No native fill, DRC, ERC, board-load, or export job was launched by this reviewer.

## Identity and geometry

- R121's board, schematic instance, BOM proposal, project-local module and exported XML bind to KOA **RN73R1ETTP1563B25**, 156 kΩ ±0.1%, with the RN73R datasheet and the new `R_KOA_RN73R1E_0402_Reflow_Vertical_B` footprint. The contract records 25 ppm/K. The original root, pad, schematic, property and graphic UUIDs remain. Pad 1 is USB_OVLO at (13.68, 19.10); pad 2 is GND at (13.68, 18.20). Each rectangular land is 0.30 × 0.40 mm in global axes, with 0.90 mm pitch: the contract's rotated manufacturer 0.40 × 0.30 mm recommendation. Board and module nominal body are 0.50 × 1.00 mm and derived courtyard 1.05 × 1.80 mm.
- C124 retains YAGEO **CC0402KRX7R9BB103**, 10 nF ±10% 50 V, with X7R in the proposal. Its center is (15.185, 19.375), pad 1 USB_DVDT_CAP at (14.685, 19.375), pad 2 GND at (15.685, 19.375). Lands remain exactly 0.50 mm square, on 1.00 mm pitch; body, UUIDs, identity and every unrelated field are unchanged. **Both board and local module** have the required 1.90 × 1.10 mm courtyard. Board bounds are (14.235, 18.825)–(16.135, 19.925). The local reference compensation is (-6.985, 0.425), preserving the global (8.2, 19.8) anchor.
- R125 remains KOA **RK73H1ETTP1000F**, 100 Ω ±1%, with pad 1 USB_DVDT and pad 2 USB_DVDT_CAP. Its whole raw footprint is byte-identical to C, SHA `04786777a69813cd3e6460d1a9f38ce8e253081b0880e8a7981b378d6767d525`; its schematic, local module and XML component are also unchanged.

## Exact scope and logical parity

- Of 383 footprints, only R121 and C124 differ from C. The other 381 raw footprint records are byte-identical, including R125. Every global reference anchor and all reference field UUID/font/mirroring are retained.
- Independently reconstructing only the allowed C→D field transforms yields the exact actual R121/C124 board records and R121/C124 modules. No extra pad setting, graphic, property, or geometry change is hidden by a dimensions-only comparison.
- Relative to C, the sole schematic instance change is R121's four identity fields: Footprint, Datasheet, Manufacturer and MPN. All other schematic objects, cached symbol definitions, pin/instance data, values and project files are exact. Only the R121 module is added; C124 module changes only its courtyard; the old TNPW module remains byte-exact and unused by active board/schematic bindings.
- The local library resolves through `${KIPRJMOD}/C124_Short_Study.pretty`; no machine-specific absolute library path was introduced.
- All **1,064 named PCB/XML pins** match with no unmatched or differently assigned pins. Every exported logical net has exactly the same membership as C. USB_DVDT is exactly U8.7/R125.1; USB_DVDT_CAP is exactly R125.2/C124.1. This verifies logical identity, not geometric continuity or signal integrity.
- Parent-produced ERC output reports 0 violations and DRC schematic parity reports 0 differences. Those reports were consumed, not reexecuted. DRC still records 12 raw unconnected items and 64 other entries: 7 dangling tracks, 1 dangling via, 22 text-height, 19 silk-over-copper and 15 silk-overlap entries. Their source-relative and physical dispositions belong to the separate full-board/geometry review; this binding pass does not waive them.

## Manufacturer, process and qualification boundaries

The reviewed RN73R PDF SHA is `758d94218acf1f87dd65704f09c0d6aec272a50953c398d40887e42a6dae6e0e`; KOA Appendix B SHA is `03eb70d555534488a49675926bc56ef43ce53307df7fe807f298548491b0beed`. Their preserved, separately reviewed geometry inputs are used here through the frozen contract. This review verifies the actual construction against that evidence; it is not a new catalog, stock or supplier investigation.

- RN73R catalog support does **not** establish equivalent TNPW endurance/humidity drift, pulse performance, exact-SKU availability or delivery. R120 MPN/TCR and thermal tracking remain unknown.
- R121's 1.05 × 1.80 mm courtyard is an ordinary derived screening envelope, not a manufacturer-approved courtyard. C124's explicit maximum-envelope courtyard fixes the stale smaller CAD envelope, but dimensional binding alone does not establish neighboring clearance under placement/solder tolerances or assembly-process acceptance.
- All six reviewed pads use ordinary B.Cu/B.Mask/B.Paste layers, with no local solder-mask/paste margin, pad clearance override or added model. Relevant project rules remain unchanged. **No actual generated mask/paste Gerber or stencil-process approval is claimed.** Any generated artwork review belongs to the parent's manufacturing-output checks.
- No 3D model was invented; board/switch/socket/plate/case and height-fit qualification are not established here.
- Selection, procurement, assembly, manufacturer-process, active startup/SPICE, hardware stability and RN73R-versus-TNPW drift equivalence remain false.

Detailed assertions and exact differences are in `COMPONENT_BINDING_REVIEW.json`; the independent S-expression/XML reader is `review_binding.py`.

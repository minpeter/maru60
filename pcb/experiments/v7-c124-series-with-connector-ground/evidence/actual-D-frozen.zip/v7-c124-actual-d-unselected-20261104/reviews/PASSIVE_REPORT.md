# C124 D: nominal circuit and passive-model binding

**The actual D circuit matches the existing 100 Ω + 10 nF nominal model class. Fresh independent-formulation numerical replay passes, but there is no model of the actual D parasitics or active startup.** No CAD or BOM is changed or selected by this report.

## Exact snapshot

- Source c770: `c77020ca2e05de0684d6a6c724bf568937bd7e7cbce4ce0c395924d0c97a8e4a`.
- Actual filled D: `f987edb49e7eb99e6db711ea428a5efb66a36653fe9dce77b02aae12f281441b`.
- Construction contract: `15835e0f49534e7250626669db5645dccc80034a3cefd88651578731627d62bd`.
- Actual D netlist: `05b0032974c95e00e7b563cd8ffadadbb6d72d51e266706f813609c08ca01b6d`.
- Original passive-screen manifest: `bb52c290f0867c4da5934e6f543fedbd785e79ae39f363d24f5cf645659e0201`; all nine original manifest members checked unchanged.

Read-only native KiCad and XML checks confirm the order **U8.7 → R125.1; R125.2 → C124.1; C124.2 → GND**. Source c770 has direct 10 nF and no R125. Exact actual properties agree with the contract:

- R125: KOA RK73H1ETTP1000F, 100 Ω ±1%.
- C124: YAGEO CC0402KRX7R9BB103, 10 nF ±10%, 50 V X7R.
- R121: KOA RN73R1ETTP1563B25, 156 kΩ ±0.1%, ±25 ppm/K.
- U8: TPS259470LRPW.
- UVLO: 620 kΩ/267 kΩ; OVLO: 590 kΩ/156 kΩ. All four nominal values and sense-node membership remain unchanged.

The actual pads and part fields were checked, not merely the proposal JSON. Source/candidate hashes remained unchanged after native reads, and their via UUID inventories match. These checks do not replace the separate corrected physical-contact/reference/DRC audit or establish a physical absence of bypass from net names alone.

## Actual geometry versus original V4 plan

Named native track endpoints, widths, layers and UUIDs match the construction objects. The original source's 31 retired-track witnesses and three retained tracks are also rebound. These are centerline sums, **not impedance extraction or a unique current path**:

| Metric | Original V4 plan, mm | Actual D witness, mm |
|---|---:|---:|
| DVDT pin side including retained stub | 1.660404265 | 1.960582292 |
| Resistor-to-capacitor track | 1.103279203 | 1.090366911 |
| C124 ground track | 0.699231721 | 0.699231721 |
| UVLO replacement chain | 9.247623313 | 9.436568489 |
| Complete OVLO main arm | 10.172156727 | 10.414184183 |

D's pin-side witness comprises 1.925226953 mm of three main new segments plus the retained 0.035355339 mm stub. Support-restoration copper overlaps the main route; summing it again would not be a meaningful series path. C124 moved while existing endpoints remain within pads, so track lengths do not include an invented pad-center bridge. Neither shorter copper nor unchanged reference planes establishes noise improvement or a quantified loop inductance.

## Independent numerical formulations, replayed unchanged

No new parasitic values were inferred from D. The same three hypothetical R/L/C sets and nominal options were used. Fresh execution of the existing independent verification produced:

- 10,818 original CSV points versus a separately derived series-impedance reduction: maximum pointwise complex relative error **2.73×10⁻¹⁰**.
- 18 DVDT + 18 divider native ngspice AC cases, 601 points each: **21,636 points**.
- Native DVDT versus independent equations: **1.05×10⁻⁹** maximum pointwise error; dividers: **1.08×10⁻¹⁵**.
- All numerical summary values match the prior independent review exactly.

The native passive circuit adds a numerical 1 TΩ pin-ground DC reference, absent from the original ideal model. Its reference equation includes that path; the maximum effect over the swept band is **1.94×10⁻⁷**. It is not measured IC leakage. Logs retain the isolated runtime's missing-spinit warning; no external or active model is required by these passive decks.

This is a fresh replay of previously independent algebra/native formulations, **not a newly staffed independent review**. A new reviewer could not start because the thread limit was reached. Routing owns the separate independent actual-CAD audit. No existing sealed result or source file was edited.

## What the numerical comparison means

In the central assumed example at 1 MHz, pin-side pickup from a hypothetical 1 V aggressor gives 0.009991 mV for direct 10 nF and 0.063887 mV for 100 Ω + 10 nF. Capacitor-side injection gives approximately 0.009995 mV for either. These values remain unchanged because the assumed network is unchanged. They are **not actual old-board/D noise predictions**, and they do not establish that the series resistor improves every interference path.

The direct 8.2 nF alternative remains only a nominal-C sensitivity case. It is not the actual D BOM and does not model NP0 behavior. Divider supply and return are ideal AC grounds; actual supply/ground movement, pin clamps, comparator behavior, leakage, timing and field coupling are absent.

## Limits retained after actual construction

- C124's exact part identity does not supply a measured effective capacitance, DC-bias, temperature, aging, ESR or ESL model. The AC calculation uses nominal C.
- RN73R has different endurance/humidity limits from the former TNPW0603 proposal. The exact-value humidity caveat and unspecified R120 MPN/TCR/thermal tracking remain open. Initial value equality does not imply stability equivalence. The sealed R121 review is referenced by copied report, source hashes and calculation inputs.
- R125's 0402 pulse/reset performance is not qualified. Its nominal RC product is not an eFuse ramp or rail-ready time. The controller's discharge behavior, actual capacitor voltage, repetition and thermal environment are absent.
- No accepted VBUS_FUSED fault/transient maximum has been established. The earlier bounded 5/5.25/5.5 V static examples do not supply one; the 23 V resistor diagnostic is outside the stated OVLO recommended range.
- No active eFuse execution, startup, brownout recovery, reverse input, ESD, EMC, production or measured hardware result is added here. All such qualification remains false.
- Actual D native/material/reference gates are maintained separately by routing. This packet does not adopt the candidate, even if those geometric checks pass later.

## Reproduce

`/usr/bin/python3 bind_native.py` requires the exact recorded source/candidate PCB paths and installed native KiCad. It does not save or fill a board. `python replay/check_numerics.py` reproduces the independent passive algebra/native checks using installed NumPy and libngspice44.2; create the netlists/runs directories first. Run both with separate private HOME and XDG directories as recorded in RUNTIME.json. Replays write only their own output files. No model installation, vendor-equation change or new active-device experiment occurred.

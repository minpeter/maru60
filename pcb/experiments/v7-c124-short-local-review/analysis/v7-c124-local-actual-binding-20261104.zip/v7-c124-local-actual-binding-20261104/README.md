# Actual V4 C124 binding, independent read-only check

**The actual filled candidate matches the reviewed V4 circuit/geometry basis. This is not adoption or hardware qualification.** No selected CAD, candidate CAD, schematic, fill or rule was edited by this review.

## Exact artifacts

- Source: `7c23d6ea36b158fa706fa3e05f0e1f10fa4aa435deecb2d3bcd38c71cf9f8cb1`.
- Actual filled V4: `8c45df3642599be269697ce9b225fe55ee6b886dce713b77f6ced533ea268fb6`, at `/tmp/v7-c124-rebound-short/isolated-v4/filled/pcb/maru60.kicad_pcb` when reviewed.
- Reviewed geometry: `0201051134f0ffe6b1498a83687ba7a3dc909869d6f117fdb8456351d4ad5c51`.
- Companion independent passive review ZIP: `v7-c124-local-passive-review-20261104.zip`, SHA256 `f43187de10c12568eb1bb7aefee9f82cbb032aed518af618a92cf7f75202e508`.

This actual snapshot derives from **7c23**. The later metadata/artwork selection and any carry to it are **not covered** by this exact-board binding. A new hash needs an explicit delta proof.

## Independently verified

`bind_actual.py` loaded both native boards, compared actual track/via geometry/net records, checked pad LayerSets and shapes, compared full serialized zone blocks and independently parsed the supplied native XML. Board hashes were checked before/after, with no save or fill.

- Exactly 31 named old tracks retired and 21 ordinary tracks added. No new via or hole.
- All **10,640 retained track/via records** unchanged.
- Actual inventory: **9,742 tracks, 919 vias, 383 footprints**.
- All 21 added tracks match the exact V4 vertices, widths, nets and layers, including both old-C124 ground support bridges.
- Actual B-side R125, C124 and R121 pad positions/sizes/shapes/net identities match the reviewed plan. Their physical LayerSets are B.Cu/B.Mask/B.Paste. Native PAD.GetLayer() is not used to infer physical copper side.
- U8, R120, R122 and R123 native component/pad records are unchanged. R121 stays nominally 156 kΩ ±0.1%; its proposed exact part and lands are nevertheless explicit changes.
- The native XML gives U8.7→R125.1 on USB_DVDT and R125.2→C124.1 on USB_DVDT_CAP. UVLO/OVLO divider node lists are unchanged. No schematic bypass exists.
- **All 12 complete serialized zone records are byte-identical** to 7c23, including saved inner-plane fills. This verifies saved fill identity, not impedance or universal analog quietness.

## Actual lengths

| Item | Length, mm |
|---|---:|
| New pin-side traces | 1.625048926 |
| Complete pin-side path including retained U8.7 stub | 1.660404265 |
| R125 to C124 | 1.103279203 |
| New C124 return leg to existing U8 GND via | 0.699231721 |
| New UVLO replacement chain | 9.247623313 |
| New OVLO replacement tracks | 7.856388450 |
| All added GND tracks, including support bridges | 2.049231721 |

The new OVLO tracks are not the complete arm: retained source tracks bring it to 10.172156727 mm. Relative to the source, UVLO grows 0.894932120 mm and the full OVLO arm grows 1.410519448 mm. The original direct DVDT route was 1.892869416 mm; the new combined pin-side plus capacitor-side copper is 2.763683468 mm. Shorter pin-side copper does not mean shorter total copper or extracted lower noise.

## What transfers, and what does not

The actual nominal R/C values and topology agree with the frozen passive screen. Its hypothetical sensitivity cases can therefore be discussed against this exact candidate. None of their assumed pin capacitance, trace R/L, capacitor ESR/ESL or coupling was inferred from these lengths. No numerical board-noise prediction, dielectric model, reset waveform or active-controller validation transfers.

The smaller KOA 0402 resistor retains its separate pulse/voltage/temperature gate. The proposed Murata part's current approval-sheet/assembly caveat and the R121 component/land change also remain explicit. The original failed remote-via candidate's geometry and any 0603 resistor assumptions must not be inherited.

Physical contact partitions, DRC/ERC/parity acceptance, full source-root replay, assembly fit and any later selected-source carry are owned by separate actual-candidate checks. The supplied ERC and raw-delta files are copied as upstream provenance, not represented as independent reruns here. Net names and pad locations alone are not proof of no physical short or analog stability. No circuit or hardware qualification is granted.

## Reproduce

Run `python3 bind_actual.py` with KiCad pcbnew and the exact source/candidate/plan paths recorded in the script. `actual-binding.json` records the complete relevant native component and changed-copper witnesses. The copied XML/fill/raw-delta/ERC reports are provenance inputs; exact board files remain in the routing packet rather than being duplicated here.

#!/usr/bin/env python3
"""Read-only actual V4 identity and geometry binding; no physical acceptance."""
import collections,hashlib,json,math,os,pathlib,re,shutil,xml.etree.ElementTree as ET
r=pathlib.Path(__file__).resolve().parent;w=r.parent;os.environ['XDG_CONFIG_HOME']=str(r/'runtime')
import pcbnew as k
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=w/'pcb-v7-recovery-20261104/pcb/experiments/v7-reference-legibility/candidate/pcb/maru60.kicad_pcb'
base=pathlib.Path('/tmp/v7-c124-rebound-short');actual=base/'isolated-v4/filled/pcb/maru60.kicad_pcb';plan=base/'main/counterfactual-uvlo-r121-ipc-v4.json'
srcsha='7c23d6ea36b158fa706fa3e05f0e1f10fa4aa435deecb2d3bcd38c71cf9f8cb1';newsha='8c45df3642599be269697ce9b225fe55ee6b886dce713b77f6ced533ea268fb6';assert sha(source)==srcsha and sha(actual)==newsha
plan_sha=sha(plan);assert plan_sha=='0201051134f0ffe6b1498a83687ba7a3dc909869d6f117fdb8456351d4ad5c51';p=json.loads(plan.read_text());xy=lambda v:[k.ToMM(v.x),k.ToMM(v.y)]
def read(path):
 b=k.LoadBoard(str(path));tr={};fp={};holes={}
 for t in b.GetTracks():
  via=isinstance(t,k.PCB_VIA);d={'kind':'via'if via else'track','net':t.GetNetname(),'start':xy(t.GetStart()),'end':xy(t.GetEnd()),'width':k.ToMM(t.GetWidth(k.F_Cu)if via else t.GetWidth()),'layer':b.GetLayerName(t.GetLayer()),'length_mm':0 if via else k.ToMM(t.GetLength())}
  if via:d.update(drill_mm=k.ToMM(t.GetDrillValue()),layer_pair=[b.GetLayerName(t.TopLayer()),b.GetLayerName(t.BottomLayer())])
  tr[t.m_Uuid.AsString()]=d
 for f in b.GetFootprints():
  for pad in f.Pads():
   if pad.GetDrillSize().x or pad.GetDrillSize().y:holes[pad.m_Uuid.AsString()]={'center':xy(pad.GetPosition()),'drill':xy(pad.GetDrillSize()),'attribute':pad.GetAttribute(),'orientation':pad.GetOrientationDegrees()}
  if f.GetReference()in['U8','R120','R121','R122','R123','C124','R125']:
   fp[f.GetReference()]={'uuid':f.m_Uuid.AsString(),'value':f.GetValue(),'footprint':str(f.GetFPID().GetLibItemName()),'center':xy(f.GetPosition()),'layer':b.GetLayerName(f.GetLayer()),'pads':sorted([{'uuid':pad.m_Uuid.AsString(),'number':pad.GetNumber(),'net':pad.GetNetname(),'center':xy(pad.GetPosition()),'bbox_size':[k.ToMM(pad.GetBoundingBox().GetWidth()),k.ToMM(pad.GetBoundingBox().GetHeight())],'shape':pad.GetShape(),'layers':[b.GetLayerName(q)for q in pad.GetLayerSet().Seq()]}for pad in f.Pads()if pad.GetNumber()],key=lambda z:z['uuid'])}
 return tr,fp,len(list(b.GetFootprints())),holes
a,af,ac,ah=read(source);b,bf,bc,bh=read(actual);assert ah==bh; removed=set(a)-set(b);added=set(b)-set(a);retained=set(a)&set(b)
assert removed==set(p['uvlo_retirement_uuids']+p['retired_other_uuids'])and len(removed)==31 and len(added)==21 and len(retained)==10640
assert all(a[u]==b[u]for u in retained);assert all(b[u]['kind']=='track'for u in added)
assert sum(t['kind']=='via'for t in b.values())==919 and sum(t['kind']=='track'for t in b.values())==9742 and bc==383
for ref in ['U8','R120','R122','R123']:assert af[ref]==bf[ref]
assert af['R121']['value']==bf['R121']['value']=='156k 0.1%';assert bf['R125']['value']=='100 1%'and bf['C124']['value']=='10nF 10% 50V'
def key(t):return(t['net'],tuple(sorted([tuple(t['start']),tuple(t['end'])])),round(t['width'],6),t['layer'])
expected=[{'net':q['net'],'start':[round(v,6)for v in q['start']],'end':[round(v,6)for v in q['end']],'width':.15,'layer':'B.Cu'}for q in p['routes']]
expected += [{'net':'GND','start':[15.5,17.725],'end':[14.9,17.275],'width':.28,'layer':'B.Cu'},{'net':'GND','start':[15.5,17.85],'end':[15.5,17.25],'width':.2,'layer':'B.Cu'}]
assert collections.Counter(key(q)for q in expected)==collections.Counter(key(b[u])for u in added)
padexpect={'R125':{'1':('USB_DVDT',[15.99,20.27],[.4,.3]),'2':('USB_DVDT_CAP',[15.09,20.27],[.4,.3])},'C124':{'1':('USB_DVDT_CAP',[15.005,19.17],[.35,.5]),'2':('GND',[15.755,19.17],[.35,.5])},'R121':{'1':('USB_OVLO',[13.68,19.45],[1,.9]),'2':('GND',[13.68,17.85],[1,.9])}}
for ref,entries in padexpect.items():
 assert bf[ref]['layer']=='B.Cu'
 for pad in bf[ref]['pads']:
  net,at,size=entries[pad['number']];assert pad['net']==net and pad['center']==at and pad['bbox_size']==size and set(pad['layers'])=={'B.Cu','B.Mask','B.Paste'}
  assert pad['shape']==k.PAD_SHAPE_RECT
# Exact byte equality of top-level serialized zone records, not just area or count.
def zones(path):
 text=path.read_text();out=[]
 for m in re.finditer(r'^\t\(zone\b',text,re.M):
  end=re.search(r'^\t\)',text[m.end():],re.M);assert end is not None;out.append(text[m.start():m.end()+end.end()])
 assert len(out)==12;return out
za,zb=zones(source),zones(actual);assert collections.Counter(za)==collections.Counter(zb)
lengths={n:sum(b[u]['length_mm']for u in added if b[u]['net']==n)for n in ['USB_DVDT','USB_DVDT_CAP','USB_UVLO','USB_OVLO','GND']};lengths['USB_DVDT_pin_side_with_retained_stub']=lengths['USB_DVDT']+b['7c494a73-d1ac-5d4f-ae2d-7b26d0b153f3']['length_mm'];lengths['C124_ground_leg']=math.dist([15.755,19.17],[16.4,18.9])
xml=base/'isolated-v4/qa/netlist.xml';root=ET.parse(xml).getroot();nets={n.attrib['name']:sorted((d.attrib['ref'],d.attrib['pin'])for d in n.findall('node'))for n in root.findall('./nets/net')}
assert nets['USB_DVDT']==[('R125','1'),('U8','7')]and nets['USB_DVDT_CAP']==[('C124','1'),('R125','2')]
assert nets['USB_UVLO']==[('R122','2'),('R123','1'),('U8','1')]and nets['USB_OVLO']==[('R120','2'),('R121','1'),('U8','2')]
assert sha(source)==srcsha and sha(actual)==newsha and sha(plan)==plan_sha
out={'status':'ACTUAL_GEOMETRY_AND_XML_BOUND_NOT_ACCEPTED_OR_QUALIFIED','source_sha256':srcsha,'actual_filled_sha256':newsha,'plan_geometry_sha256':plan_sha,'source_is_7c23_not_later_artwork_carry':True,'no_save_fill_mutation':True,'inventory':{'old_tracks_vias':len(a),'actual_tracks':9742,'actual_vias':919,'footprints':bc,'removed_tracks':len(removed),'added_tracks':len(added),'retained_tracks_vias_unchanged':len(retained),'new_holes':0,'unchanged_footprint_drill_count':len(ah)},'all_21_added_routes_match_plan':True,'all_12_zone_records_byte_identical':True,'zone_record_hashes':[hashlib.sha256(z.encode()).hexdigest()for z in sorted(za)],'added_route_lengths_mm':lengths,'old_components':af,'actual_components':bf,'removed_objects':{u:a[u]for u in sorted(removed)},'added_objects':{u:b[u]for u in sorted(added)},'native_XML_sha256':sha(xml),'native_XML_selected_nodes':{n:nets[n]for n in ['USB_DVDT','USB_DVDT_CAP','USB_UVLO','USB_OVLO']},'limits':['Native geometric and net identity is not a physical contact/clearance/no-bypass acceptance.','No active device, field extraction, assembly, measured noise or hardware qualification.','Later metadata/artwork selection carry requires separate exact comparison.']}
(r/'actual-binding.json').write_text(json.dumps(out,indent=2)+'\n')
for f in ['netlist.xml','netlist-order.json','native-fill.json','erc-with-library.json','filled-raw-object-delta.json']:
 q=base/'isolated-v4/qa'/f;shutil.copyfile(q,r/'inputs'/f)
print(json.dumps({n:out[n]for n in ['status','actual_filled_sha256','inventory','all_21_added_routes_match_plan','all_12_zone_records_byte_identical','added_route_lengths_mm']},indent=2))

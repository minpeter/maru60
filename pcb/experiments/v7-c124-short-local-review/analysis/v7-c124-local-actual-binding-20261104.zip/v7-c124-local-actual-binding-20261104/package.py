#!/usr/bin/env python3
import hashlib,json,pathlib,zipfile
r=pathlib.Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in r.rglob('*')if p.is_file()and not any(x in p.relative_to(r).parts for x in ['runtime','__pycache__'])and p not in [r/'MANIFEST.json',r/'ARCHIVE.json']]
m={'scope':'Independent actual V4 geometry/XML/saved-fill binding, no acceptance or hardware qualification','source_sha256':'7c23d6ea36b158fa706fa3e05f0e1f10fa4aa435deecb2d3bcd38c71cf9f8cb1','actual_sha256':'8c45df3642599be269697ce9b225fe55ee6b886dce713b77f6ced533ea268fb6','files':{str(p.relative_to(r)):sha(p)for p in sorted(files)}}
(r/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');files.append(r/'MANIFEST.json');zpath=r.with_suffix('.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,str(pathlib.Path(r.name)/p.relative_to(r)))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None
 for rel,h in m['files'].items():assert hashlib.sha256(z.read(r.name+'/'+rel)).hexdigest()==h
out={'archive':str(zpath),'bytes':zpath.stat().st_size,'sha256':sha(zpath),'files':len(files)};(r/'ARCHIVE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

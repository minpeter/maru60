#!/usr/bin/env python3
import hashlib,json,pathlib,zipfile
r=pathlib.Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[p for p in r.rglob('*')if p.is_file()and not any(x in p.relative_to(r).parts for x in ['runtime-native','__pycache__'])and p not in [r/'MANIFEST.json',r/'ARCHIVE.json']]
m={'scope':'Independent review of frozen hypothetical V4 passive screen; numerical eligibility only, no actual-CAD or hardware acceptance','screen_manifest_sha256':'bb52c290f0867c4da5934e6f543fedbd785e79ae39f363d24f5cf645659e0201','files':{str(p.relative_to(r)):sha(p)for p in sorted(files)}}
(r/'MANIFEST.json').write_text(json.dumps(m,indent=2)+'\n');files.append(r/'MANIFEST.json');zpath=r.with_suffix('.zip')
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(files):z.write(p,str(pathlib.Path(r.name)/p.relative_to(r)))
with zipfile.ZipFile(zpath)as z:
 assert z.testzip()is None
 for rel,h in m['files'].items():assert hashlib.sha256(z.read(r.name+'/'+rel)).hexdigest()==h
out={'archive':str(zpath),'bytes':zpath.stat().st_size,'sha256':sha(zpath),'files':len(files)};(r/'ARCHIVE.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))

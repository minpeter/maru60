#!/usr/bin/env python3
import hashlib,json,math,os,pathlib,shutil
r=pathlib.Path(__file__).resolve().parent;w=r.parent
os.environ['XDG_CONFIG_HOME']=str(r/'runtime-native')
import pcbnew as k
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
board=w/'pcb-v7-recovery-20261104/pcb/experiments/v7-reference-legibility/candidate/pcb/maru60.kicad_pcb';expected='7c23d6ea36b158fa706fa3e05f0e1f10fa4aa435deecb2d3bcd38c71cf9f8cb1';assert sha(board)==expected
screen=w/'v7-c124-local-passive-screen-20261104';assert sha(screen/'MANIFEST.json')=='bb52c290f0867c4da5934e6f543fedbd785e79ae39f363d24f5cf645659e0201'
sm=json.loads((screen/'MANIFEST.json').read_text());assert all(sha(screen/f)==h for f,h in sm['files'].items())
plan=pathlib.Path('/tmp/v7-c124-rebound-short');pm=plan/'PLAN_MANIFEST.json';pmanifest=json.loads(pm.read_text());assert pmanifest['source_sha256']==expected
verified=[]
for item in pmanifest['files']:
 p=plan/item['path'];assert sha(p)==item['sha256'];verified.append({'path':item['path'],'sha256':item['sha256'],'bytes':p.stat().st_size})
sreport=json.loads((screen/'results.json').read_text());assert sha(pm)==sreport['plan_manifest_sha256']
gpath=plan/'main/counterfactual-uvlo-r121-ipc-v4.json';g=json.loads(gpath.read_text());assert g['source_sha']==expected
b=k.LoadBoard(str(board));tracks={t.m_Uuid.AsString():{'net':t.GetNetname(),'length_mm':0 if isinstance(t,k.PCB_VIA)else k.ToMM(t.GetLength()),'kind':'via'if isinstance(t,k.PCB_VIA)else'track','layer':b.GetLayerName(t.GetLayer())}for t in b.GetTracks()};components={}
for f in b.GetFootprints():
 if f.GetReference()in['U8','C124','R120','R121','R122','R123']:
  components[f.GetReference()]={'value':f.GetValue(),'pads':[{'number':p.GetNumber(),'net':p.GetNetname()}for p in f.Pads()if p.GetNumber()]}
assert {n:components[n]['value']for n in ['R120','R121','R122','R123']}=={'R120':'590k 0.1%','R121':'156k 0.1%','R122':'620k 0.1%','R123':'267k 0.1%'}
assert components['U8']['value']=='TPS259470LRPW'and components['C124']['value']=='10nF 10% 50V'
old_uv=sum(tracks[u]['length_mm']for u in g['uvlo_retirement_uuids']);assert len(g['uvlo_retirement_uuids'])==24
retired=g['retired_other_uuids'];assert len(retired)==7
old_dv=sum(tracks[u]['length_mm']for u in retired if tracks[u]['net']=='USB_DVDT')
old_ov=sum(tracks[u]['length_mm']for u in retired if tracks[u]['net']=='USB_OVLO')
stub=tracks['7c494a73-d1ac-5d4f-ae2d-7b26d0b153f3']['length_mm']
arm_retained_uuids=['e218cfe4-e4ba-5b6c-985d-8f1da39a4402','6e2e82bf-1a07-562e-b012-9a61a7509e00'];arm_retained=sum(tracks[u]['length_mm']for u in arm_retained_uuids)
new={}
for route in g['routes']:
 length=math.dist(route['start'],route['end']);assert abs(length-route['length'])<1e-12
 new[route['net']]=new.get(route['net'],0)+length
lengths={'DVDT_old_direct':old_dv+stub,'DVDT_retained_stub':stub,'DVDT_retired':old_dv,'DVDT_new_pin_side':stub+new['USB_DVDT'],'DVDT_new_cap_side':new['USB_DVDT_CAP'],'C124_new_ground':new['GND'],'UVLO_retired_chain':old_uv,'UVLO_new_chain':new['USB_UVLO'],'UVLO_delta':new['USB_UVLO']-old_uv,'OVLO_old_arm':old_ov+arm_retained,'OVLO_new_arm':new['USB_OVLO']+arm_retained,'OVLO_delta':new['USB_OVLO']-old_ov}
expected_lengths={'DVDT_new_pin_side':1.660404265,'DVDT_new_cap_side':1.103279203,'C124_new_ground':.699231721,'UVLO_delta':.894932120,'OVLO_delta':1.410519448}
for n,value in expected_lengths.items():assert abs(lengths[n]-value)<1e-9,(n,lengths[n])
assert sha(board)==expected and sha(pm)==sreport['plan_manifest_sha256']and sha(screen/'MANIFEST.json')=='bb52c290f0867c4da5934e6f543fedbd785e79ae39f363d24f5cf645659e0201'
out={'scope':'Independent selected-native values/lengths and frozen plan/screen hash binding; not actual candidate, contact/refill or impedance extraction','selected_PCB_sha256':expected,'screen_manifest_sha256':sha(screen/'MANIFEST.json'),'plan_manifest_sha256':sha(pm),'all_plan_members_verified':verified,'components':components,'native_source_inventory':{'tracks':sum(t['kind']=='track'for t in tracks.values()),'vias':sum(t['kind']=='via'for t in tracks.values()),'footprints':len(list(b.GetFootprints()))},'lengths_mm':lengths,'retired_source_objects':{u:tracks[u]for u in g['uvlo_retirement_uuids']+retired},'retained_arm_source_objects':{u:tracks[u]for u in arm_retained_uuids},'no_board_save_fill_or_mutation':True,'lengths_used_to_assign_parasitics':False}
(r/'source-binding.json').write_text(json.dumps(out,indent=2)+'\n')
for src,dst in [(pm,'plan-manifest.json'),(gpath,'plan-geometry.json'),(plan/'EXPANDED_V4_PLAN.md','EXPANDED_V4_PLAN.md')]:shutil.copyfile(src,r/'inputs'/dst)
print(json.dumps({'screen_manifest_sha256':sha(screen/'MANIFEST.json'),'plan_members_verified':len(verified),'native_source_inventory':out['native_source_inventory'],'lengths_mm':lengths},indent=2))

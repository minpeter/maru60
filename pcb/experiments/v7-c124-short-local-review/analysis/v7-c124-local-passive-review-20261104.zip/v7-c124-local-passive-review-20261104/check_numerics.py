#!/usr/bin/env python3
"""Independent impedance reductions and native branch-level SPICE checks."""
import csv,json,pathlib,subprocess,sys
import numpy as np
r=pathlib.Path(__file__).resolve().parent
report=json.loads((r/'inputs/screen/results.json').read_text());rows=list(csv.DictReader((r/'inputs/screen/ac-sweep.csv').open()));sc={x[0]:x[1:]for x in report['scenarios']};op={x[0]:x[1:]for x in report['options']}
def impedance(f,pars,opt,loc,gleak=0):
 cp,rt,lt,esr,esl,cc=pars;c,rs=opt;s=2j*np.pi*np.asarray(f);zl=rt+rs+s*lt;zc=esr+s*esl+1/(s*c)
 if loc=='pin':return s*cc*(zl+zc)/(1+(gleak+s*(cp+cc))*(zl+zc))
 return s*cc*zc/(1+s*cc*zc+(gleak+s*cp)*(zc+zl+s*cc*zl*zc))
errs=[]
for row in rows:
 h=impedance(float(row['frequency_Hz']),sc[row['scenario']],op[row['option']],row['pickup_location']);old=complex(float(row['Vpin_per_1V_aggressor_real']),float(row['Vpin_per_1V_aggressor_imag']));errs.append(float(abs(old-h)/abs(h)))
assert len(errs)==10818 and max(errs)<1e-8
checks=[];divchecks=[]
def run(name,lines):
 deck=r/'netlists'/f'{name}.cir';deck.write_text('\n'.join([name]+lines+['.ac dec 100 100 100Meg','.end'])+'\n');out=r/'runs'/name
 subprocess.run([sys.executable,str(r/'ngrun.py'),str(deck),str(out),'v(pin)'],check=True,stdout=subprocess.DEVNULL,timeout=30)
 return np.loadtxt(out/'waveform.txt',skiprows=1)
for scenario,pars in sc.items():
 cp,rt,lt,esr,esl,cc=pars
 for option,(c,rs)in op.items():
  for loc in ['pin','cap']:
   name=f'{scenario}-{option}-{loc}';data=run(name,[f'Rlink pin link {rt+rs:.16g}',f'Llink link cap {lt:.16g}',f'Resr cap esr {esr:.16g}',f'Lesl esr esl {esl:.16g}',f'C124 esl 0 {c:.16g}',f'Cpin pin 0 {cp:.16g}',f'Ccouple ag {loc} {cc:.16g}','Vag ag 0 DC 0 AC 1','Rdc pin 0 1e12'])
   unregularized=impedance(data[:,0],pars,[c,rs],loc);ex=impedance(data[:,0],pars,[c,rs],loc,1e-12);perturb=float(np.max(abs(ex-unregularized)/abs(unregularized)));assert perturb<3e-7
   h=data[:,1]+1j*data[:,2];err=float(np.max(abs(h-ex)/abs(ex)));assert len(data)==601 and err<1e-8
   checks.append({'scenario':scenario,'option':option,'location':loc,'points':len(data),'max_pointwise_relative_complex_error':err,'regularization_relative_effect_max':perturb})
for i,p in enumerate(report['divider_scenarios']):
 top=p['Rtop_ohm'];bottom=p['Rbottom_ohm'];cg=p['assumed_Cground_pF']*1e-12;cc=p['assumed_Ccoupling_pF']*1e-12;rt=top*bottom/(top+bottom)
 data=run(f'divider-{i:02d}-{p["node"]}',[f'Rtop pin 0 {top:.16g}',f'Rbottom pin 0 {bottom:.16g}',f'Cground pin 0 {cg:.16g}',f'Ccouple ag pin {cc:.16g}','Vag ag 0 AC 1'])
 s=2j*np.pi*data[:,0];ex=s*cc/(1/top+1/bottom+s*(cg+cc));h=data[:,1]+1j*data[:,2];err=float(np.max(abs(h-ex)/abs(ex)));assert err<1e-10
 assert abs(p['Rthevenin_ohm']/rt-1)<1e-14 and abs(p['decay_tau_us']/(rt*(cg+cc)*1e6)-1)<1e-14
 assert abs(p['high_frequency_ratio_Cc_over_Ctotal']/(cc/(cg+cc))-1)<1e-14
 val=abs(2j*np.pi*1e6*cc/(1/rt+2j*np.pi*1e6*(cg+cc)));assert abs(p['at_1MHz_magnitude_V_per_V']/val-1)<1e-14
 divchecks.append({'index':i,'node':p['node'],'points':len(data),'max_pointwise_relative_complex_error':err})
out={'scope':'Independent algebra plus branch-level native ngspice; passive mathematical verification only. No active model or extracted parasitics.','csv_points':len(rows),'max_csv_pointwise_relative_complex_error':max(errs),'native_dvdt_checks':checks,'native_divider_checks':divchecks,'native_points':sum(c['points']for c in checks+divchecks),'native_DVDT_regularization':'1 Tohm pin-to-ground numerical DC path, separately included in reference equation, not measured pin leakage','max_regularization_relative_effect':max(c['regularization_relative_effect_max']for c in checks),'max_dvdt_native_pointwise_relative_complex_error':max(c['max_pointwise_relative_complex_error']for c in checks),'max_divider_native_pointwise_relative_complex_error':max(c['max_pointwise_relative_complex_error']for c in divchecks)}
(r/'numerical-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if not isinstance(v,list)},indent=2))

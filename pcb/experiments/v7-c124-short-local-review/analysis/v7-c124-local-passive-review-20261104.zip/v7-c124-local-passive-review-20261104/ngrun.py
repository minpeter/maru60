#!/usr/bin/env python3
import ctypes,sys,pathlib
p=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(sys.argv[2]).resolve();out.mkdir(exist_ok=True,parents=True)
w=out/'waveform.txt'
if w.exists():w.unlink()
lib=ctypes.CDLL('libngspice.so.0');logs=[]
CB=ctypes.CFUNCTYPE(ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_void_p);EXIT=ctypes.CFUNCTYPE(ctypes.c_int,ctypes.c_int,ctypes.c_bool,ctypes.c_bool,ctypes.c_int,ctypes.c_void_p)
@CB
def log(s,i,u):logs.append(s.decode(errors='replace'));return 0
@EXIT
def ex(s,a,b,i,u):logs.append(f'EXIT {s} {a} {b}');return 0
lib.ngSpice_Init.argtypes=[CB,CB,EXIT,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p];lib.ngSpice_Init(log,log,ex,None,None,None,None)
lib.ngSpice_Command.argtypes=[ctypes.c_char_p]
for cmd in ['set numdgt=15','version','source '+str(p),'run','set wr_singlescale','set wr_vecnames','wrdata '+str(w)+' '+' '.join(sys.argv[3:])]:
 rc=lib.ngSpice_Command(cmd.encode());logs.append(f'COMMAND {rc}: {cmd}')
(out/'ngspice.log').write_text('\n'.join(logs)+'\n')
assert w.exists() and not any(t in '\n'.join(logs).lower()for t in ['singular matrix','simulation interrupted','circuit not parsed','no convergence','simulation aborted'])

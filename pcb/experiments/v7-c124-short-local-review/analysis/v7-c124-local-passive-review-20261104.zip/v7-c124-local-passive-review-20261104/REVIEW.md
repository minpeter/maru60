# Independent review: local C124 V4 passive screen

## Eligibility

**Pass for bounded passive sensitivity analysis only.** No algebraic or parameter-value defect was found in the frozen screen. It cannot select the 100 Ω layout, approve a smaller capacitor, or establish actual noise/startup/protection behavior. CAD construction/refill/contact/reference acceptance remains a separate task.

Reviewed screen manifest SHA256: `bb52c290f0867c4da5934e6f543fedbd785e79ae39f363d24f5cf645659e0201`. The input copy under `inputs/screen/` is frozen. The original screen and selected CAD were not changed by this reviewer. The author separately incorporated the review's wording and selected-netlist checks before freezing this version.

## Independent checks

1. Verified the complete screen manifest and every one of the **11 members** of the exact plan manifest. Native KiCad read-only extraction confirms selected PCB `7c23d6ea36b158fa706fa3e05f0e1f10fa4aa435deecb2d3bcd38c71cf9f8cb1`, TPS259470LRPW, direct C124 10 nF, UVLO 620 kΩ/267 kΩ and OVLO 590 kΩ/156 kΩ. Hashes remain unchanged after extraction.
2. Re-derived the response using series impedances, rather than reusing the screen's two-node determinant. All **10,818 complex CSV points** agree within **2.73×10⁻¹⁰ pointwise relative error**. This pointwise metric supplements the author's global-normalized matrix comparison.
3. Constructed separate branch-level native ngspice circuits: **18 DVDT AC cases and 18 divider AC cases**, 601 points each, **21,636 points total**. Native DVDT versus independently reduced equations agrees within **1.05×10⁻⁹** pointwise relative error. Divider agreement is within **1.08×10⁻¹⁵**. Divider time constants, resistance reductions and high-frequency ratios also match.
4. Visually checked the frozen plot: labels distinguish the nominal-C-only alternative and explicitly disclaim controller/extracted-parasitic/board predictions.

The native DVDT circuit needs a DC reference because an ideal all-capacitive passive model is floating at DC. The initial unregularized run was rejected for its singular operating point; its log is retained. Subsequent native cases add an explicitly numerical **1 TΩ pin-to-ground path** and include it in the independent reference equation. Its maximum relative effect over 100 Hz–100 MHz is **1.94×10⁻⁷**. It is not measured pin leakage. No original-screen model or result was silently changed, and no active eFuse model was used.

## Source-derived geometry binding

The following are independently reproduced from exact selected native track UUIDs and the V4 plan vertices. They are **lengths, not extracted parasitics**.

| Quantity | Length, mm |
|---|---:|
| Old direct DVDT route | 1.892869416 |
| Retained U8.7 stub | 0.035355339 |
| Proposed complete pin-side route | 1.660404265 |
| Proposed resistor-to-capacitor route | 1.103279203 |
| Proposed C124 ground leg | 0.699231721 |
| Retired UVLO chain | 8.352691193 |
| Proposed UVLO chain | 9.247623313 |
| UVLO increase | 0.894932120 |
| Old OVLO arm | 8.761637279 |
| Proposed complete OVLO arm | 10.172156727 |
| OVLO increase | 1.410519448 |

All 31 named retired source tracks were read from the actual selected board. The two retained OVLO-arm segments and U8.7 stub are separately recorded in `source-binding.json`. No board was saved, filled or relabeled. Proposed route arithmetic does not constitute actual-candidate measurement. The 0.699 mm leg terminates at the existing U8 ground via, but its common plane/via impedance is still unknown.

## Conclusions that are supported

- Adding series resistance changes how the passive network responds to noise entering at different nodes. It is not blanket noise reduction. The component's active-controller purpose is not tested by this model.
- The 8.2 nF option changes only nominal C while retaining the same hypothetical ESR/ESL and routing assumptions. It is **not** a simulation of NP0 dielectric, a particular TDK part, or its bias/temperature/aging behavior.
- The divider pickup model holds its supply and return at ideal AC ground. It does not simulate supply ripple, common ground movement, comparator thresholds, pin leakage/clamps or protection timing. The added UVLO/OVLO route lengths do not determine the assumed coupling capacitances.
- “Low/central/high” are selected examples, not component corners or statistical/worst-case bounds. No confidence interval or actual old/new board ratio follows from them.
- R121's proposed exact part and lands are explicit changes even though the nominal 156 kΩ value/topology stay fixed. Its temperature/assembly behavior and the old resistor's unknown exact identity are outside these AC calculations.

## Separate 0402 resistor gate

The [KOA RK73H primary data](https://www.koaspeer.com/catimages/Products/RK73H/RK73H.pdf), independently reopened for this review, gives the 1E/0402 100 Ω option 0.1 W and ±100 ppm/K. Its 75 V working/100 V overload family ceilings do not permit those voltages at 100 Ω: the nominal continuous rated voltage is min(√(0.1 W×100 Ω),75 V), approximately **3.162 V**. Derating applies above the specified 70°C ambient or 125°C terminal reference, with terminal-temperature guidance taking priority. The 1E five-second overload test uses twice rated voltage and allows resistance change; it does not qualify repetitive resets. The pulse curves are explicitly unassured.

For an **assumed** 11 nF initially charged capacitor discharged only through 100 Ω, 5 V would imply 0.25 W initial power and 0.1375 µJ energy; 10 V would imply 1 W and 0.55 µJ. These are conditional calculations, not actual DVDT voltages or reset waveforms. Actual discharge path, repetition, thermal conditions and part pulse performance remain unqualified. Do not inherit the former 0603 resistor assessment or use input USB voltage as an assumed resistor voltage.

## Reproduction and limits

`bind_source.py` requires exact selected CAD and plan files at the recorded workspace paths. `check_numerics.py` reads the frozen screen copy and regenerates the separate native circuits using `ngrun.py`, Python/NumPy and `libngspice.so.0`.

```
python3 bind_source.py
python3 check_numerics.py
```

The review supplies no new transient waveform, active-controller result, field extraction, assembly approval or powered qualification. The emerging actual V4 board must be bound separately after its stable fill and native reports are available; no proposed-plan pass silently transfers to actual CAD.
